import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

type ProjectDetails = {
  projectName: string;
  location: string;
  capacityKW: number;
  // Add more fields as needed
};

export default function BankabilityAnalysisForm() {
  const [isLoading, setIsLoading] = useState(false);
  const [project, setProject] = useState<ProjectDetails>({
    projectName: '',
    location: '',
    capacityKW: 0,
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    try {
      // TODO: Implement API call to backend
      console.log('Submitting project:', project);
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));
    } catch (error) {
      console.error('Error submitting analysis:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type } = e.target;
    setProject(prev => ({
      ...prev,
      [name]: type === 'number' ? parseFloat(value) || 0 : value,
    }));
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>New Bankability Analysis</Cardtitle>
        <CardDescription>
          Get a comprehensive bankability report for your renewable energy project in minutes.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="projectName">Project Name</Label>
            <Input
              id="projectName"
              name="projectName"
              value={project.projectName}
              onChange={handleChange}
              placeholder="Enter project name"
              required
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="location">Location</Label>
            <Input
              id="location"
              name="location"
              value={project.location}
              onChange={handleChange}
              placeholder="Enter project location"
              required
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="capacityKW">Capacity (kW)</Label>
            <Input
              id="capacityKW"
              name="capacityKW"
              type="number"
              min="0"
              step="0.01"
              value={project.capacityKW}
              onChange={handleChange}
              placeholder="Enter project capacity in kW"
              required
            />
          </div>
          
          <div className="flex justify-end">
            <Button type="submit" disabled={isLoading}>
              {isLoading ? 'Analyzing...' : 'Run Analysis'}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
