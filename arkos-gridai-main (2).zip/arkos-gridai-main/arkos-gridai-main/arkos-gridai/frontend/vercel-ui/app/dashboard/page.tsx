import { redirect } from 'next/navigation';
import { createServerComponentClient } from '@supabase/auth-helpers-nextjs';
import { cookies } from 'next/headers';
import { BankabilityAnalysisForm } from '@/components/bankability/analysis-form';

export default async function Dashboard() {
  const supabase = createServerComponentClient({ cookies });
  const { data: { session } } = await supabase.auth.getSession();

  if (!session) {
    redirect('/login');
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="mb-8">
        <h1 className="text-3xl font-bold">Welcome back, {session.user.email?.split('@')[0]}</h1>
        <p className="text-muted-foreground">Run a new bankability analysis or view your projects.</p>
      </div>
      
      <div className="grid gap-8">
        <section>
          <h2 className="text-2xl font-semibold mb-4">New Analysis</h2>
          <BankabilityAnalysisForm />
        </section>
        
        <section>
          <h2 className="text-2xl font-semibold mb-4">Recent Projects</h2>
          <div className="rounded-lg border p-4 text-center">
            <p className="text-muted-foreground">No projects yet. Run your first analysis to get started.</p>
          </div>
        </section>
      </div>
    </div>
  );
}
