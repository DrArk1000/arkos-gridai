// Feature flags for gradual rollout
// Toggle these to enable/disable features per environment/plan
export const FEATURES = {
  // Core features (always enabled)
  BANKABILITY_ANALYSIS: true,
  
  // Pro features (gated behind subscription)
  ASSET_MANAGEMENT: false,
  TEAM_COLLABORATION: false,
  ADVANCED_ANALYTICS: false,
  PDF_EXPORT: false,
} as const;

export type Feature = keyof typeof FEATURES;

export function isFeatureEnabled(feature: Feature): boolean {
  // In production, check user's subscription
  if (typeof window !== 'undefined' && window.ENV?.ENVIRONMENT === 'production') {
    return window.ENV.FEATURES?.[feature] ?? FEATURES[feature];
  }
  return FEATURES[feature];
}
