export default function Home() {
  return <div className="p-8">Arkos GridAI MVP – Frontend Placeholder</div>;
}
