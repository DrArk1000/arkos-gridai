# Arkos GridAI MVP scaffold

This repository contains a monorepo for the Arkos GridAI MVP, including backend, frontend, and infrastructure components.
