"use client"

import SiteAnalyzer from "./site-analyzer"

export default function Page() {
  return <SiteAnalyzer />
}
