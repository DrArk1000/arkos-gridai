import GridAnalyzer from "./grid-analyzer"

export default function Home() {
  return <GridAnalyzer />
}
