import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Analysis } from "@/types/analysis";
import { OverviewTab } from "./tabs/OverviewTab";
import { SolarPotentialTab } from "./tabs/SolarPotentialTab";
import { FinancialTab } from "./tabs/FinancialTab";
import { EnvironmentalTab } from "./tabs/EnvironmentalTab";

type AnalysisTabsProps = {
  analysis: Analysis;
  activeTab: string;
  onTabChange: (tab: string) => void;
};

export function AnalysisTabs({ analysis, activeTab, onTabChange }: AnalysisTabsProps) {
  return (
    <Tabs value={activeTab} onValueChange={onTabChange} className="w-full">
      <TabsList className="grid w-full grid-cols-4">
        <TabsTrigger value="overview">Overview</TabsTrigger>
        <TabsTrigger 
          value="solar" 
          disabled={analysis.status !== 'completed'}
          title={analysis.status !== 'completed' ? 'Complete the analysis to view solar potential' : ''}
        >
          Solar Potential
        </TabsTrigger>
        <TabsTrigger 
          value="financial" 
          disabled={analysis.status !== 'completed'}
          title={analysis.status !== 'completed' ? 'Complete the analysis to view financials' : ''}
        >
          Financials
        </TabsTrigger>
        <TabsTrigger 
          value="environmental" 
          disabled={analysis.status !== 'completed'}
          title={analysis.status !== 'completed' ? 'Complete the analysis to view environmental impact' : ''}
        >
          Environmental
        </TabsTrigger>
      </TabsList>

      <TabsContent value="overview" className="mt-6">
        <OverviewTab analysis={analysis} />
      </TabsContent>
      
      <TabsContent value="solar" className="mt-6">
        <SolarPotentialTab analysis={analysis} />
      </TabsContent>
      
      <TabsContent value="financial" className="mt-6">
        <FinancialTab analysis={analysis} />
      </TabsContent>
      
      <TabsContent value="environmental" className="mt-6">
        <EnvironmentalTab analysis={analysis} />
      </TabsContent>
    </Tabs>
  );
}
