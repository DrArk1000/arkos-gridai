import { Analysis } from "@/types/analysis";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { MapPin, Sun, Zap, Leaf, Activity, Clock, CheckCircle, AlertCircle, Calendar, Gauge } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

type OverviewTabProps = {
  analysis: Analysis;
};

export function OverviewTab({ analysis }: OverviewTabProps) {
  return (
    <div className="space-y-6">
      {/* Status and Key Metrics */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium">Status</CardTitle>
              <div className={`h-2 w-2 rounded-full ${
                analysis.status === 'completed' ? 'bg-green-500' : 
                analysis.status === 'processing' ? 'bg-yellow-500' : 'bg-gray-500'
              }`} />
            </div>
            <div className="text-2xl font-bold">
              {analysis.status.charAt(0).toUpperCase() + analysis.status.slice(1)}
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-xs text-muted-foreground">
              Last updated: {new Date(analysis.updated_at).toLocaleString()}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium">Location</CardTitle>
              <MapPin className="h-4 w-4 text-muted-foreground" />
            </div>
            <div className="text-2xl font-bold">
              {analysis.site_name || 'Unnamed Site'}
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-xs text-muted-foreground">
              {analysis.address || `${analysis.latitude?.toFixed(4)}, ${analysis.longitude?.toFixed(4)}`}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium">System Size</CardTitle>
              <Zap className="h-4 w-4 text-muted-foreground" />
            </div>
            <div className="text-2xl font-bold">
              {analysis.parameters?.system_size || 'N/A'} kW
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-xs text-muted-foreground">
              {analysis.parameters?.panel_type || 'N/A'} panels
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium">Analysis ID</CardTitle>
              <Calendar className="h-4 w-4 text-muted-foreground" />
            </div>
            <div className="text-sm font-mono">
              {analysis.id}
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-xs text-muted-foreground">
              Created: {new Date(analysis.created_at).toLocaleDateString()}
            </div>
          </CardContent>
        </Card>
      </div>

      {analysis.status === 'completed' && analysis.results && (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          <Card>
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium">Annual Production</CardTitle>
                <Sun className="h-4 w-4 text-muted-foreground" />
              </div>
              <div className="text-2xl font-bold">
                {Math.round(analysis.results.annual_production_kwh).toLocaleString()} kWh
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-xs text-muted-foreground">
                {analysis.results.capacity_factor ? 
                  `Capacity factor: ${(analysis.results.capacity_factor * 100).toFixed(1)}%` : 
                  'N/A'}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium">Financial Summary</CardTitle>
                <Activity className="h-4 w-4 text-muted-foreground" />
              </div>
              <div className="text-2xl font-bold">
                ${analysis.results.financial?.lcoe?.toFixed(2) || 'N/A'}/kWh
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-xs text-muted-foreground">
                {analysis.results.financial?.irr ? 
                  `IRR: ${(analysis.results.financial.irr * 100).toFixed(1)}%` : 
                  'N/A'}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium">Environmental Impact</CardTitle>
                <Leaf className="h-4 w-4 text-muted-foreground" />
              </div>
              <div className="text-2xl font-bold">
                {analysis.results.environmental?.co2_saved ? 
                  `${Math.round(analysis.results.environmental.co2_saved / 1000)} t` : 
                  'N/A'}
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-xs text-muted-foreground">
                {analysis.results.environmental?.equivalent_trees ? 
                  `Equivalent to ${analysis.results.environmental.equivalent_trees} trees` : 
                  'N/A'}
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {analysis.status === 'processing' && (
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center space-x-4">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
              <div>
                <h3 className="font-medium">Analysis in Progress</h3>
                <p className="text-sm text-muted-foreground">
                  Your analysis is being processed. This may take a few minutes.
                </p>
              </div>
            </div>
            <div className="mt-4 w-full bg-gray-200 rounded-full h-2.5">
              <div 
                className="bg-blue-600 h-2.5 rounded-full animate-pulse" 
                style={{ width: '75%' }}
              ></div>
            </div>
          </CardContent>
        </Card>
      )}

      {analysis.status === 'failed' && (
        <Card className="border-red-200 bg-red-50 dark:border-red-900 dark:bg-red-950/20">
          <CardContent className="pt-6">
            <div className="flex items-start space-x-4">
              <AlertCircle className="h-5 w-5 text-red-500 mt-0.5" />
              <div>
                <h3 className="font-medium text-red-800 dark:text-red-200">Analysis Failed</h3>
                <p className="text-sm text-red-700 dark:text-red-300 mt-1">
                  {analysis.error_message || 'An error occurred while processing your analysis.'}
                </p>
                <div className="mt-3">
                  <Button variant="outline" size="sm" className="border-red-200 text-red-700">
                    Retry Analysis
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* System Configuration */}
      <Card>
        <CardHeader>
          <CardTitle>System Configuration</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            <div className="space-y-2">
              <h3 className="text-sm font-medium">Panel Details</h3>
              <dl className="space-y-2">
                <div className="flex justify-between">
                  <dt className="text-sm text-muted-foreground">Panel Type</dt>
                  <dd className="text-sm font-medium">{analysis.parameters?.panel_type || 'N/A'}</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-sm text-muted-foreground">Panel Count</dt>
                  <dd className="text-sm font-medium">{analysis.parameters?.panel_count || 'N/A'}</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-sm text-muted-foreground">Panel Power</dt>
                  <dd className="text-sm font-medium">
                    {analysis.parameters?.panel_power ? `${analysis.parameters.panel_power}W` : 'N/A'}
                  </dd>
                </div>
              </dl>
            </div>

            <div className="space-y-2">
              <h3 className="text-sm font-medium">System Orientation</h3>
              <dl className="space-y-2">
                <div className="flex justify-between">
                  <dt className="text-sm text-muted-foreground">Tilt Angle</dt>
                  <dd className="text-sm font-medium">
                    {analysis.parameters?.tilt_angle ? `${analysis.parameters.tilt_angle}°` : 'N/A'}
                  </dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-sm text-muted-foreground">Azimuth</dt>
                  <dd className="text-sm font-medium">
                    {analysis.parameters?.azimuth ? `${analysis.parameters.azimuth}°` : 'N/A'}
                  </dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-sm text-muted-foreground">Tracking</dt>
                  <dd className="text-sm font-medium">
                    {analysis.parameters?.tracking_type || 'Fixed'}
                  </dd>
                </div>
              </dl>
            </div>

            <div className="space-y-2">
              <h3 className="text-sm font-medium">Financial Parameters</h3>
              <dl className="space-y-2">
                <div className="flex justify-between">
                  <dt className="text-sm text-muted-foreground">Electricity Rate</dt>
                  <dd className="text-sm font-medium">
                    {analysis.parameters?.electricity_rate ? `$${analysis.parameters.electricity_rate}/kWh` : 'N/A'}
                  </dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-sm text-muted-foreground">Incentives</dt>
                  <dd className="text-sm font-medium">
                    {analysis.parameters?.incentives ? `$${analysis.parameters.incentives}` : 'None'}
                  </dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-sm text-muted-foreground">System Cost</dt>
                  <dd className="text-sm font-medium">
                    {analysis.parameters?.system_cost ? `$${analysis.parameters.system_cost.toLocaleString()}` : 'N/A'}
                  </dd>
                </div>
              </dl>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
