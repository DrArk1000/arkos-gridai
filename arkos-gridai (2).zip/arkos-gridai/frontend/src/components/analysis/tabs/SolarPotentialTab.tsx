import { Analysis } from "@/types/analysis";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Sun, Zap, Gauge, Clock, TrendingUp, MapPin } from "lucide-react";

type SolarPotentialTabProps = {
  analysis: Analysis;
};

export function SolarPotentialTab({ analysis }: SolarPotentialTabProps) {
  if (!analysis.results) return null;
  
  return (
    <div className="space-y-6">
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Annual Production</CardTitle>
            <CardDescription>Estimated energy production for this location</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-64 bg-muted rounded-md flex items-center justify-center">
              <p className="text-muted-foreground">Annual production chart will be displayed here</p>
            </div>
            <div className="mt-4 grid grid-cols-3 gap-4 text-center">
              <div>
                <p className="text-sm text-muted-foreground">Annual</p>
                <p className="text-xl font-medium">
                  {Math.round(analysis.results.annual_production_kwh).toLocaleString()} kWh
                </p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Daily Avg</p>
                <p className="text-xl font-medium">
                  {Math.round(analysis.results.annual_production_kwh / 365).toLocaleString()} kWh
                </p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Capacity Factor</p>
                <p className="text-xl font-medium">
                  {analysis.results.capacity_factor ? 
                    `${(analysis.results.capacity_factor * 100).toFixed(1)}%` : 'N/A'}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Monthly Production</CardTitle>
            <CardDescription>Seasonal variation in energy production</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-64 bg-muted rounded-md flex items-center justify-center">
              <p className="text-muted-foreground">Monthly production chart will be displayed here</p>
            </div>
            <div className="mt-4">
              <h4 className="text-sm font-medium mb-2">Peak Production</h4>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Month</p>
                  <p>May</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Production</p>
                  <p>1,250 kWh</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Solar Irradiance</CardTitle>
            <CardDescription>Available solar energy at this location</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Sun className="h-5 w-5 text-yellow-500" />
                  <span>Annual Irradiance</span>
                </div>
                <span className="font-medium">
                  {analysis.results.solar_irradiance?.annual ? 
                    `${analysis.results.solar_irradiance.annual} kWh/m²/year` : 'N/A'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <TrendingUp className="h-5 w-5 text-blue-500" />
                  <span>Peak Sun Hours</span>
                </div>
                <span className="font-medium">
                  {analysis.results.solar_irradiance?.peak_sun_hours ? 
                    `${analysis.results.solar_irradiance.peak_sun_hours} hours/day` : 'N/A'}
                </span>
              </div>
              <div className="h-48 bg-muted rounded-md mt-4 flex items-center justify-center">
                <p className="text-muted-foreground">Solar irradiance chart will be displayed here</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>System Performance</CardTitle>
            <CardDescription>Performance metrics for the proposed system</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Zap className="h-5 w-5 text-yellow-500" />
                  <span>System Size</span>
                </div>
                <span className="font-medium">
                  {analysis.parameters?.system_size || 'N/A'} kW
                </span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Gauge className="h-5 w-5 text-blue-500" />
                  <span>Performance Ratio</span>
                </div>
                <span className="font-medium">
                  {analysis.results.performance_ratio ? 
                    `${(analysis.results.performance_ratio * 100).toFixed(1)}%` : 'N/A'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Clock className="h-5 w-5 text-gray-500" />
                  <span>Degradation Rate</span>
                </div>
                <span className="font-medium">0.5% per year</span>
              </div>
            </div>
            
            <div className="pt-4 border-t">
              <h4 className="text-sm font-medium mb-2">Energy Production</h4>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Year 1</p>
                  <p className="font-medium">
                    {Math.round(analysis.results.annual_production_kwh).toLocaleString()} kWh
                  </p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Year 25</p>
                  <p className="font-medium">
                    {Math.round(analysis.results.annual_production_kwh * Math.pow(0.995, 24)).toLocaleString()} kWh
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Shade Analysis</CardTitle>
          <CardDescription>Impact of shading on system performance</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-6 md:grid-cols-2">
            <div className="space-y-4">
              <div className="h-64 bg-muted rounded-md flex items-center justify-center">
                <p className="text-muted-foreground">Shade analysis visualization will be displayed here</p>
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span>Shade Impact</span>
                  <span className="font-medium">
                    {analysis.results.shade_impact ? 
                      `-${(analysis.results.shade_impact * 100).toFixed(1)}%` : 'Minimal'}
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div 
                    className="bg-yellow-500 h-2.5 rounded-full" 
                    style={{ 
                      width: analysis.results.shade_impact ? 
                        `${Math.min(100, analysis.results.shade_impact * 100)}%` : '5%' 
                    }}
                  ></div>
                </div>
              </div>
            </div>
            <div className="space-y-4">
              <h3 className="font-medium">Shade Sources</h3>
              <ul className="space-y-2">
                {analysis.results.shade_sources?.length ? (
                  analysis.results.shade_sources.map((source, index) => (
                    <li key={index} className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <MapPin className="h-4 w-4 text-muted-foreground" />
                        <span>{source.direction}</span>
                      </div>
                      <span className="text-sm text-muted-foreground">
                        {source.distance}m away
                      </span>
                    </li>
                  ))
                ) : (
                  <li className="text-sm text-muted-foreground">No significant shading sources detected</li>
                )}
              </ul>
              
              <div className="pt-4 border-t">
                <h4 className="text-sm font-medium mb-2">Recommendations</h4>
                <ul className="space-y-1 text-sm">
                  {analysis.results.shade_impact > 0.1 ? (
                    <>
                      <li>• Consider tree trimming to the west and south</li>
                      <li>• Microinverters or power optimizers recommended</li>
                      <li>• Consider ground-mount system as an alternative</li>
                    </>
                  ) : (
                    <li>• No significant shading issues detected</li>
                  )}
                </ul>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
