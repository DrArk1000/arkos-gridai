import { Analysis } from "@/types/analysis";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { DollarSign, TrendingUp, BarChart2, Percent, Clock, Zap } from "lucide-react";

type FinancialTabProps = {
  analysis: Analysis;
};

export function FinancialTab({ analysis }: FinancialTabProps) {
  if (!analysis.results?.financial) return null;
  
  const financials = analysis.results.financial;
  const currency = analysis.parameters?.currency || 'USD';
  
  // Helper function to format currency
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency,
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(value);
  };
  
  // Calculate financial metrics
  const totalSavings = financials.annual_savings * financials.analysis_period_years;
  const paybackYears = financials.system_cost / (financials.annual_savings || 1);
  const netSavings = totalSavings - financials.system_cost;
  
  return (
    <div className="space-y-6">
      {/* Financial Summary */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium">System Cost</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </div>
            <div className="text-2xl font-bold">
              {formatCurrency(financials.system_cost)}
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-xs text-muted-foreground">
              {financials.incentives > 0 ? 
                `${formatCurrency(financials.incentives)} in incentives` : 
                'No incentives applied'}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium">Annual Savings</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </div>
            <div className="text-2xl font-bold">
              {formatCurrency(financials.annual_savings)}
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-xs text-muted-foreground">
              {financials.electricity_rate ? 
                `Based on ${analysis.results.annual_production_kwh?.toLocaleString()} kWh @ ${financials.electricity_rate} ${currency}/kWh` : 
                'N/A'}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium">Payback Period</CardTitle>
              <Clock className="h-4 w-4 text-muted-foreground" />
            </div>
            <div className="text-2xl font-bold">
              {paybackYears.toFixed(1)} years
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-xs text-muted-foreground">
              {financials.discount_rate ? 
                `With ${(financials.discount_rate * 100).toFixed(1)}% discount rate` : 
                'Simple payback period'}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium">Return on Investment</CardTitle>
              <Percent className="h-4 w-4 text-muted-foreground" />
            </div>
            <div className="text-2xl font-bold">
              {financials.irr ? `${(financials.irr * 100).toFixed(1)}%` : 'N/A'}
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-xs text-muted-foreground">
              {financials.npv ? `NPV: ${formatCurrency(financials.npv)}` : 'N/A'}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Cash Flow Analysis */}
      <Card>
        <CardHeader>
          <CardTitle>Cash Flow Analysis</CardTitle>
          <CardDescription>
            {financials.analysis_period_years}-year projected cash flow
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-64 bg-muted rounded-md flex items-center justify-center">
            <p className="text-muted-foreground">Cash flow chart will be displayed here</p>
          </div>
          
          <div className="mt-6 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            <div className="space-y-2">
              <h3 className="text-sm font-medium">Total Savings</h3>
              <p className="text-2xl font-bold">{formatCurrency(totalSavings)}</p>
              <p className="text-sm text-muted-foreground">
                Over {financials.analysis_period_years} years
              </p>
            </div>
            
            <div className="space-y-2">
              <h3 className="text-sm font-medium">Net Savings</h3>
              <p className={`text-2xl font-bold ${
                netSavings >= 0 ? 'text-green-600' : 'text-red-600'
              }`}>
                {formatCurrency(netSavings)}
              </p>
              <p className="text-sm text-muted-foreground">
                After system cost
              </p>
            </div>
            
            <div className="space-y-2">
              <h3 className="text-sm font-medium">Levelized Cost of Energy</h3>
              <p className="text-2xl font-bold">
                {financials.lcoe ? `${financials.lcoe.toFixed(2)} ${currency}/kWh` : 'N/A'}
              </p>
              <p className="text-sm text-muted-foreground">
                Average cost per kWh over system lifetime
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Financial Assumptions */}
      <Card>
        <CardHeader>
          <CardTitle>Financial Assumptions</CardTitle>
          <CardDescription>
            Parameters used in the financial analysis
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-medium mb-2">System Parameters</h3>
                <dl className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <dt className="text-muted-foreground">System Size</dt>
                    <dd>{analysis.parameters?.system_size || 'N/A'} kW</dd>
                  </div>
                  <div className="flex justify-between">
                    <dt className="text-muted-foreground">System Cost</dt>
                    <dd>{formatCurrency(financials.system_cost)}</dd>
                  </div>
                  <div className="flex justify-between">
                    <dt className="text-muted-foreground">Incentives</dt>
                    <dd>{formatCurrency(financials.incentives)}</dd>
                  </div>
                </dl>
              </div>
            </div>
            
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-medium mb-2">Financial Parameters</h3>
                <dl className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <dt className="text-muted-foreground">Electricity Rate</dt>
                    <dd>{financials.electricity_rate} {currency}/kWh</dd>
                  </div>
                  <div className="flex justify-between">
                    <dt className="text-muted-foreground">Escalation Rate</dt>
                    <dd>{(financials.electricity_escalation_rate * 100).toFixed(1)}%</dd>
                  </div>
                  <div className="flex justify-between">
                    <dt className="text-muted-foreground">Discount Rate</dt>
                    <dd>{(financials.discount_rate * 100).toFixed(1)}%</dd>
                  </div>
                </dl>
              </div>
            </div>
            
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-medium mb-2">System Performance</h3>
                <dl className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <dt className="text-muted-foreground">Annual Production</dt>
                    <dd>{analysis.results.annual_production_kwh?.toLocaleString()} kWh</dd>
                  </div>
                  <div className="flex justify-between">
                    <dt className="text-muted-foreground">Degradation</dt>
                    <dd>0.5% per year</dd>
                  </div>
                  <div className="flex justify-between">
                    <dt className="text-muted-foreground">Analysis Period</dt>
                    <dd>{financials.analysis_period_years} years</dd>
                  </div>
                </dl>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Incentives and Rebates */}
      {financials.incentives > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Incentives & Rebates</CardTitle>
            <CardDescription>
              Financial incentives applied to this project
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Incentive
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Type
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Amount
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      Federal Tax Credit (ITC)
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      Tax Credit
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {formatCurrency(financials.incentives * 0.26)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                        Available
                      </span>
                    </td>
                  </tr>
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      State Rebate Program
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      Rebate
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {formatCurrency(financials.incentives * 0.1)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                        Available
                      </span>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
