import { Badge } from "@/components/ui/badge";
import { CheckCircle2, Clock, AlertCircle, Loader2 } from "lucide-react";

type AnalysisStatus = 'pending' | 'processing' | 'completed' | 'failed';

type AnalysisStatusBadgeProps = {
  status: AnalysisStatus;
  className?: string;
};

export function AnalysisStatusBadge({ status, className = '' }: AnalysisStatusBadgeProps) {
  const statusConfig = {
    pending: {
      label: 'Pending',
      icon: Clock,
      variant: 'secondary' as const,
      iconClass: 'text-yellow-500',
    },
    processing: {
      label: 'Processing',
      icon: Loader2,
      variant: 'default' as const,
      iconClass: 'text-blue-500 animate-spin',
    },
    completed: {
      label: 'Completed',
      icon: CheckCircle2,
      variant: 'default' as const,
      iconClass: 'text-green-500',
    },
    failed: {
      label: 'Failed',
      icon: AlertCircle,
      variant: 'destructive' as const,
      iconClass: 'text-red-500',
    },
  };

  const { label, icon: Icon, variant, iconClass } = statusConfig[status] || statusConfig.pending;

  return (
    <Badge variant={variant} className={`inline-flex items-center gap-1.5 ${className}`}>
      <Icon className={`h-3.5 w-3.5 ${iconClass}`} />
      <span>{label}</span>
    </Badge>
  );
}
