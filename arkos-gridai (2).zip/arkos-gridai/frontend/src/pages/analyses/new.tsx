import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import { useAuth } from '../../contexts/AuthContext';
import Layout from '../../components/Layout';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import { Label } from '../../components/ui/label';
import { Textarea } from '../../components/ui/textarea';
import { useToast } from '../../components/ui/use-toast';
import { Loader2, MapPin, Save } from 'lucide-react';

type FormData = {
  siteName: string;
  address: string;
  latitude: number | '';
  longitude: number | '';
  description: string;
  panelType: string;
  systemSize: number | '';
  tiltAngle: number | '';
  azimuth: number | '';
};

export default function NewAnalysis() {
  const { user } = useAuth();
  const router = useRouter();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [isGeocoding, setIsGeocoding] = useState(false);
  const [formData, setFormData] = useState<FormData>({
    siteName: '',
    address: '',
    latitude: '',
    longitude: '',
    description: '',
    panelType: 'mono',
    systemSize: 5,
    tiltAngle: 30,
    azimuth: 180,
  });

  useEffect(() => {
    if (!user) {
      router.push('/login');
    }
  }, [user, router]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: name.includes('latitude') || name.includes('longitude') || 
               name.includes('systemSize') || name.includes('tiltAngle') || 
               name.includes('azimuth')
        ? value === '' ? '' : Number(value)
        : value
    }));
  };

  const handleGeocode = async () => {
    if (!formData.address) {
      toast({
        title: 'Error',
        description: 'Please enter an address',
        variant: 'destructive',
      });
      return;
    }

    setIsGeocoding(true);
    try {
      const response = await fetch(
        `https://api.mapbox.com/geocoding/v5/mapbox.places/${encodeURIComponent(formData.address)}.json?access_token=${process.env.NEXT_PUBLIC_MAPBOX_TOKEN}`
      );
      
      if (!response.ok) {
        throw new Error('Geocoding failed');
      }
      
      const data = await response.json();
      
      if (data.features && data.features.length > 0) {
        const [longitude, latitude] = data.features[0].center;
        setFormData(prev => ({
          ...prev,
          latitude: Number(latitude.toFixed(6)),
          longitude: Number(longitude.toFixed(6)),
        }));
        
        toast({
          title: 'Success',
          description: 'Location found!',
        });
      } else {
        throw new Error('No location found');
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Could not find location. Please try a different address or enter coordinates manually.',
        variant: 'destructive',
      });
    } finally {
      setIsGeocoding(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user) {
      router.push('/login');
      return;
    }

    if (formData.latitude === '' || formData.longitude === '') {
      toast({
        title: 'Error',
        description: 'Please provide location coordinates',
        variant: 'destructive',
      });
      return;
    }

    setIsLoading(true);
    
    try {
      const response = await fetch('/api/analyses', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
        },
        body: JSON.stringify({
          site_name: formData.siteName,
          address: formData.address,
          latitude: formData.latitude,
          longitude: formData.longitude,
          description: formData.description,
          parameters: {
            panel_type: formData.panelType,
            system_size: formData.systemSize,
            tilt_angle: formData.tiltAngle,
            azimuth: formData.azimuth,
          },
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to create analysis');
      }

      const data = await response.json();
      
      toast({
        title: 'Success',
        description: 'Analysis created successfully!',
      });
      
      router.push(`/analyses/${data.id}`);
    } catch (error) {
      console.error('Error creating analysis:', error);
      toast({
        title: 'Error',
        description: 'Failed to create analysis. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-3xl font-bold mb-6">New Site Analysis</h1>
          
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-4">
              <h2 className="text-xl font-semibold">Site Information</h2>
              
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="siteName">Site Name *</Label>
                  <Input
                    id="siteName"
                    name="siteName"
                    value={formData.siteName}
                    onChange={handleChange}
                    placeholder="My Solar Site"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="panelType">Panel Type</Label>
                  <select
                    id="panelType"
                    name="panelType"
                    value={formData.panelType}
                    onChange={handleChange}
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    <option value="mono">Monocrystalline</option>
                    <option value="poly">Polycrystalline</option>
                    <option value="thin-film">Thin-Film</option>
                  </select>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  name="description"
                  value={formData.description}
                  onChange={handleChange}
                  placeholder="Add any additional details about this site..."
                  rows={3}
                />
              </div>
            </div>
            
            <div className="space-y-4 pt-4 border-t">
              <h2 className="text-xl font-semibold">Location</h2>
              
              <div className="space-y-2">
                <div className="flex items-end gap-2">
                  <div className="flex-1 space-y-2">
                    <Label htmlFor="address">Address</Label>
                    <Input
                      id="address"
                      name="address"
                      value={formData.address}
                      onChange={handleChange}
                      placeholder="Enter a location or address"
                    />
                  </div>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={handleGeocode}
                    disabled={isGeocoding || !formData.address}
                    className="h-10"
                  >
                    {isGeocoding ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <MapPin className="h-4 w-4 mr-2" />
                    )}
                    Locate
                  </Button>
                </div>
                <p className="text-sm text-muted-foreground">
                  Or enter coordinates manually below
                </p>
              </div>
              
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="latitude">Latitude *</Label>
                  <Input
                    id="latitude"
                    name="latitude"
                    type="number"
                    step="any"
                    min="-90"
                    max="90"
                    value={formData.latitude}
                    onChange={handleChange}
                    placeholder="e.g., 37.7749"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="longitude">Longitude *</Label>
                  <Input
                    id="longitude"
                    name="longitude"
                    type="number"
                    step="any"
                    min="-180"
                    max="180"
                    value={formData.longitude}
                    onChange={handleChange}
                    placeholder="e.g., -122.4194"
                    required
                  />
                </div>
              </div>
              
              {formData.latitude !== '' && formData.longitude !== '' && (
                <div className="h-64 rounded-md border overflow-hidden">
                  <iframe
                    width="100%"
                    height="100%"
                    style={{ border: 0 }}
                    src={`https://www.openstreetmap.org/export/embed.html?bbox=${Number(formData.longitude) - 0.01}%2C${Number(formData.latitude) - 0.01}%2C${Number(formData.longitude) + 0.01}%2C${Number(formData.latitude) + 0.01}&amp;layer=mapnik&marker=${formData.latitude}%2C${formData.longitude}`}
                  />
                </div>
              )}
            </div>
            
            <div className="space-y-4 pt-4 border-t">
              <h2 className="text-xl font-semibold">System Configuration</h2>
              
              <div className="grid gap-4 md:grid-cols-3">
                <div className="space-y-2">
                  <Label htmlFor="systemSize">System Size (kW) *</Label>
                  <Input
                    id="systemSize"
                    name="systemSize"
                    type="number"
                    min="0.1"
                    step="0.1"
                    value={formData.systemSize}
                    onChange={handleChange}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="tiltAngle">Tilt Angle (degrees) *</Label>
                  <Input
                    id="tiltAngle"
                    name="tiltAngle"
                    type="number"
                    min="0"
                    max="90"
                    value={formData.tiltAngle}
                    onChange={handleChange}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="azimuth">Azimuth (degrees) *</Label>
                  <Input
                    id="azimuth"
                    name="azimuth"
                    type="number"
                    min="0"
                    max="359"
                    value={formData.azimuth}
                    onChange={handleChange}
                    required
                  />
                </div>
              </div>
              
              <div className="text-sm text-muted-foreground">
                <p>• 0° = North, 90° = East, 180° = South, 270° = West</p>
                <p>• For optimal production in the northern hemisphere, point panels south (180°)</p>
              </div>
            </div>
            
            <div className="flex justify-end gap-4 pt-4 border-t">
              <Button
                type="button"
                variant="outline"
                onClick={() => router.back()}
                disabled={isLoading}
              >
                Cancel
              </Button>
              
              <Button type="submit" disabled={isLoading}>
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Creating...
                  </>
                ) : (
                  <>
                    <Save className="mr-2 h-4 w-4" />
                    Create Analysis
                  </>
                )}
              </Button>
            </div>
          </form>
        </div>
      </div>
    </Layout>
  );
}
