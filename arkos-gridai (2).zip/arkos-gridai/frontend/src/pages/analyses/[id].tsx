import { useRouter } from 'next/router';
import { useEffect, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Analysis } from '@/types/analysis';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Skeleton } from '@/components/ui/skeleton';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { ArrowLeft, Download, Edit, ExternalLink, Activity, AlertCircle, Clock, CheckCircle2 } from 'lucide-react';
import { format } from 'date-fns';
import { Badge } from '@/components/ui/badge';
import { AnalysisStatusBadge } from '@/components/analysis/AnalysisStatusBadge';
import { AnalysisTabs } from '@/components/analysis/AnalysisTabs';

export default function AnalysisDetailPage() {
  const router = useRouter();
  const { id } = router.query;
  const [activeTab, setActiveTab] = useState('overview');

  // Fetch analysis data
  const { data: analysis, isLoading, error } = useQuery<Analysis>({
    queryKey: ['analysis', id],
    queryFn: async () => {
      const response = await fetch(`/api/analyses/${id}`);
      if (!response.ok) {
        throw new Error('Failed to fetch analysis');
      }
      return response.json();
    },
    enabled: !!id,
    refetchInterval: (data) => {
      // Only poll if the analysis is still processing
      return data?.status === 'processing' ? 5000 : false;
    },
  });

  // Handle tab change
  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
    // Update URL without page reload
    window.history.replaceState(null, '', `?tab=${tab}`);
  };

  // Set initial tab from URL
  useEffect(() => {
    if (router.isReady) {
      const tab = router.query.tab as string;
      if (tab && ['overview', 'solar', 'financial', 'environmental'].includes(tab)) {
        setActiveTab(tab);
      }
    }
  }, [router.isReady, router.query.tab]);

  // Handle back button
  const handleBack = () => {
    router.push('/dashboard');
  };

  // Handle delete analysis
  const handleDelete = async () => {
    if (window.confirm('Are you sure you want to delete this analysis? This action cannot be undone.')) {
      try {
        const response = await fetch(`/api/analyses/${id}`, {
          method: 'DELETE',
        });
        
        if (response.ok) {
          router.push('/dashboard');
        } else {
          const error = await response.json();
          throw new Error(error.message || 'Failed to delete analysis');
        }
      } catch (error) {
        console.error('Error deleting analysis:', error);
        alert('Failed to delete analysis. Please try again.');
      }
    }
  };

  // Handle reprocess analysis
  const handleReprocess = async () => {
    try {
      const response = await fetch(`/api/analyses/${id}/reprocess`, {
        method: 'POST',
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to reprocess analysis');
      }
      
      // Refetch the analysis to update the status
      await queryClient.invalidateQueries(['analysis', id]);
    } catch (error) {
      console.error('Error reprocessing analysis:', error);
      alert('Failed to reprocess analysis. Please try again.');
    }
  };

  // Handle export report
  const handleExport = async (format: 'pdf' | 'csv' | 'json') => {
    try {
      const response = await fetch(`/api/analyses/${id}/export?format=${format}`);
      
      if (!response.ok) {
        throw new Error('Failed to export report');
      }
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `analysis-${id}-${new Date().toISOString().split('T')[0]}.${format}`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      a.remove();
    } catch (error) {
      console.error('Error exporting report:', error);
      alert('Failed to export report. Please try again.');
    }
  };

  // Loading state
  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center space-x-4 mb-8">
          <Button variant="outline" size="icon" onClick={handleBack}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <Skeleton className="h-8 w-48" />
        </div>
        
        <div className="space-y-4">
          <Skeleton className="h-12 w-full" />
          <Skeleton className="h-64 w-full" />
        </div>
      </div>
    );
  }

  // Error state
  if (error) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center space-x-4 mb-8">
          <Button variant="outline" size="icon" onClick={handleBack}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <h1 className="text-2xl font-bold">Analysis Not Found</h1>
        </div>
        
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>
            {error instanceof Error ? error.message : 'Failed to load analysis. Please try again later.'}
          </AlertDescription>
        </Alert>
        
        <div className="mt-4">
          <Button onClick={() => router.reload()}>Retry</Button>
        </div>
      </div>
    );
  }

  // Analysis not found
  if (!analysis) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center space-x-4 mb-8">
          <Button variant="outline" size="icon" onClick={handleBack}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <h1 className="text-2xl font-bold">Analysis Not Found</h1>
        </div>
        
        <Alert>
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Not Found</AlertTitle>
          <AlertDescription>
            The requested analysis could not be found. It may have been deleted or you may not have permission to view it.
          </AlertDescription>
        </Alert>
        
        <div className="mt-4">
          <Button onClick={handleBack}>Back to Dashboard</Button>
        </div>
      </div>
    );
  }

  // Render the analysis detail page
  return (
    <div className="container mx-auto px-4 py-8">
      {/* Header */}
      <div className="flex flex-col space-y-4 md:flex-row md:items-center md:justify-between md:space-y-0 mb-8">
        <div className="flex items-center space-x-4">
          <Button variant="outline" size="icon" onClick={handleBack}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold">{analysis.site_name || 'Unnamed Site'}</h1>
            <p className="text-sm text-muted-foreground">
              Created on {format(new Date(analysis.created_at), 'MMM d, yyyy')}
            </p>
          </div>
        </div>
        
        <div className="flex flex-wrap gap-2">
          <AnalysisStatusBadge status={analysis.status} />
          
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => handleExport('pdf')}
            disabled={analysis.status !== 'completed'}
          >
            <Download className="h-4 w-4 mr-2" />
            Export PDF
          </Button>
          
          <Button 
            variant="outline" 
            size="sm" 
            onClick={handleReprocess}
            disabled={analysis.status === 'processing'}
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            {analysis.status === 'processing' ? 'Processing...' : 'Reprocess'}
          </Button>
          
          <Button 
            variant="outline" 
            size="sm" 
            onClick={handleDelete}
            className="text-red-600 hover:bg-red-50 hover:text-red-700"
          >
            <Trash2 className="h-4 w-4 mr-2" />
            Delete
          </Button>
        </div>
      </div>
      
      {/* Main content */}
      <div className="space-y-6">
        {/* Analysis Tabs */}
        <AnalysisTabs 
          analysis={analysis} 
          activeTab={activeTab} 
          onTabChange={handleTabChange} 
        />
      </div>
    </div>
  );
}
