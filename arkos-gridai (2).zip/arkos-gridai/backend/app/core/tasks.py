from typing import Any, Dict
from fastapi import BackgroundTasks
from .celery_config import app


def process_analysis_background(
    analysis_id: int,
    user_id: int,
    background_tasks: BackgroundTasks
) -> Dict[str, Any]:
    """
    Add an analysis processing task to the background
    """
    # In production, we'll use Celery for background processing
    if app.conf.task_always_eager:
        # In test/dev with eager mode, call the task directly
        from app.worker import process_analysis
        return process_analysis(analysis_id, user_id)
    else:
        # In production, add to Celery queue
        task = process_analysis.apply_async(
            args=[analysis_id, user_id],
            queue='analysis'
        )
        return {"task_id": task.id, "status": "processing"}


def get_task_status(task_id: str) -> Dict[str, Any]:
    """
    Get the status of a Celery task
    """
    if not task_id:
        return {"status": "error", "message": "No task ID provided"}
    
    try:
        result = app.AsyncResult(task_id)
        response = {
            "task_id": task_id,
            "status": result.status,
            "result": result.result if result.ready() else None
        }
        
        if result.failed():
            response["error"] = str(result.result)
        
        return response
    except Exception as e:
        return {"status": "error", "message": str(e)}
