import os
from celery import Celery
from ..core.config import settings

# Set the default Django settings module for the 'celery' program.
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'app.core.settings')

app = Celery('arkos_gridai')

# Using a string here means the worker doesn't have to serialize
# the configuration object to child processes.
app.config_from_object('django.conf:settings', namespace='CELERY')

# Load task modules from all registered Django app configs.
app.autodiscover_tasks()

# Configure Redis as the broker and result backend
app.conf.broker_url = settings.CELERY_BROKER_URL
app.conf.result_backend = settings.CELERY_RESULT_BACKEND
app.conf.task_serializer = 'json'
app.conf.result_serializer = 'json'
app.conf.accept_content = ['json']
app.conf.timezone = 'UTC'
app.conf.enable_utc = True

# Task execution settings
app.conf.task_track_started = True
app.conf.task_time_limit = 30 * 60  # 30 minutes
app.conf.task_soft_time_limit = 25 * 60  # 25 minutes

# Task routes
app.conf.task_routes = {
    'app.worker.process_analysis': {'queue': 'analysis'},
}

# Beat Schedule
app.conf.beat_schedule = {
    'cleanup-old-tasks': {
        'task': 'app.worker.cleanup_old_tasks',
        'schedule': 3600.0,  # Every hour
    },
}
