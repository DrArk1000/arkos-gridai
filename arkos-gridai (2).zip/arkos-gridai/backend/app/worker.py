import logging
import time
from typing import Dict, Any
from datetime import datetime, timedelta

from sqlalchemy.orm import Session

from .core.celery_config import app
from .core.database import SessionLocal
from .models.analysis import Analysis
from .schemas.analysis import AnalysisResults
from .services.analysis import (
    complete_analysis_processing,
    fail_analysis_processing
)

logger = logging.getLogger(__name__)

def get_db():
    """Get database session"""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.task(bind=True, name="process_analysis")
def process_analysis(self, analysis_id: int, user_id: int) -> Dict[str, Any]:
    """
    Process an analysis in the background.
    This is a Celery task that will be executed asynchronously.
    """
    db = next(get_db())
    
    try:
        logger.info(f"Starting analysis processing for analysis_id: {analysis_id}")
        
        # Get the analysis from the database
        analysis = db.query(Analysis).filter(
            Analysis.id == analysis_id,
            Analysis.owner_id == user_id
        ).first()
        
        if not analysis:
            logger.error(f"Analysis not found: {analysis_id}")
            return {"status": "error", "message": "Analysis not found"}
        
        # Simulate processing time (replace with actual processing logic)
        logger.info(f"Processing analysis: {analysis_id}")
        time.sleep(10)  # Simulate processing time
        
        # Generate mock results (replace with actual analysis)
        results = AnalysisResults(
            risk_score=0.85,
            connection_score=0.9,
            curtailment_score=0.75,
            delay_score=0.8,
            estimated_cost=150000.0,
            estimated_revenue=25000.0,
            payback_period=6.0,  # years
            risk_factors={
                "grid_congestion": "moderate",
                "solar_irradiance": "high",
                "land_use": "suitable",
                "environmental_impact": "low"
            },
            report_url=f"/api/v1/analyses/{analysis_id}/report"
        )
        
        # Update analysis with results
        complete_analysis_processing(
            db=db,
            analysis_id=analysis_id,
            results=results,
            user_id=user_id
        )
        
        logger.info(f"Completed analysis processing for analysis_id: {analysis_id}")
        return {"status": "success", "analysis_id": analysis_id}
        
    except Exception as e:
        logger.error(f"Error processing analysis {analysis_id}: {str(e)}", exc_info=True)
        
        # Update analysis with error
        if 'analysis' in locals():
            fail_analysis_processing(
                db=db,
                analysis_id=analysis_id,
                error_message=str(e),
                user_id=user_id
            )
        
        return {"status": "error", "message": str(e)}
    finally:
        db.close()

@app.task(name="cleanup_old_tasks")
def cleanup_old_tasks():
    """Clean up old task results from the result backend"""
    logger.info("Running cleanup of old tasks")
    
    # Get the Celery result backend
    backend = app.backend
    
    try:
        # Get all task results
        task_ids = backend.get_all_task_results()
        cutoff = datetime.utcnow() - timedelta(days=7)  # Keep results for 7 days
        
        deleted = 0
        for task_id in task_ids:
            result = backend.get_task_meta(task_id)
            if result.get('date_done') and result['date_done'].replace(tzinfo=None) < cutoff:
                backend.delete_task_meta(task_id)
                deleted += 1
        
        logger.info(f"Cleaned up {deleted} old task results")
        return {"status": "success", "deleted": deleted}
    except Exception as e:
        logger.error(f"Error cleaning up old tasks: {str(e)}", exc_info=True)
        return {"status": "error", "message": str(e)}
