from datetime import datetime
from typing import List, Optional, Dict, Any
from fastapi import HTTPException, status
from sqlalchemy.orm import Session
from sqlalchemy import desc

from ..models.analysis import Analysis
from ..models.user import User
from ..schemas.analysis import (
    AnalysisCreate, AnalysisUpdate, Analysis as AnalysisSchema,
    AnalysisStatus, AnalysisResults, AnalysisPagination
)

def get_analysis(db: Session, analysis_id: int, user_id: int) -> Optional[Analysis]:
    """Get a single analysis by ID if the user has access to it"""
    analysis = db.query(Analysis).filter(
        Analysis.id == analysis_id,
        Analysis.owner_id == user_id
    ).first()
    if not analysis:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Analysis not found"
        )
    return analysis

def get_analyses(
    db: Session,
    user_id: int,
    skip: int = 0,
    limit: int = 100,
    status: Optional[AnalysisStatus] = None,
    search: Optional[str] = None
) -> AnalysisPagination:
    """Get paginated list of analyses for a user with optional filtering"""
    query = db.query(Analysis).filter(Analysis.owner_id == user_id)
    
    if status:
        query = query.filter(Analysis.status == status)
    
    if search:
        search = f"%{search}%"
        query = query.filter(
            (Analysis.site_name.ilike(search)) |
            (Analysis.address.ilike(search))
        )
    
    total = query.count()
    items = query.order_by(desc(Analysis.updated_at)).offset(skip).limit(limit).all()
    
    return AnalysisPagination(
        items=items,
        total=total,
        page=skip // limit + 1,
        size=limit,
        total_pages=(total + limit - 1) // limit if limit > 0 else 0
    )

def create_analysis(
    db: Session,
    analysis_data: AnalysisCreate,
    user_id: int
) -> Analysis:
    """Create a new analysis for a user"""
    db_analysis = Analysis(
        **analysis_data.dict(exclude_unset=True),
        owner_id=user_id,
        status=AnalysisStatus.PENDING
    )
    db.add(db_analysis)
    db.commit()
    db.refresh(db_analysis)
    return db_analysis

def update_analysis(
    db: Session,
    analysis_id: int,
    analysis_data: AnalysisUpdate,
    user_id: int
) -> Analysis:
    """Update an existing analysis"""
    db_analysis = get_analysis(db, analysis_id, user_id)
    
    update_data = analysis_data.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(db_analysis, field, value)
    
    db_analysis.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(db_analysis)
    return db_analysis

def delete_analysis(db: Session, analysis_id: int, user_id: int) -> bool:
    """Delete an analysis if the user has permission"""
    db_analysis = get_analysis(db, analysis_id, user_id)
    db.delete(db_analysis)
    db.commit()
    return True

def start_analysis_processing(db: Session, analysis_id: int, user_id: int) -> Analysis:
    """Mark an analysis as being processed"""
    db_analysis = get_analysis(db, analysis_id, user_id)
    
    if db_analysis.status != AnalysisStatus.PENDING:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Analysis is not in a pending state"
        )
    
    db_analysis.status = AnalysisStatus.PROCESSING
    db_analysis.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(db_analysis)
    return db_analysis

def complete_analysis_processing(
    db: Session,
    analysis_id: int,
    results: AnalysisResults,
    user_id: int
) -> Analysis:
    """Mark an analysis as completed with results"""
    db_analysis = get_analysis(db, analysis_id, user_id)
    
    if db_analysis.status != AnalysisStatus.PROCESSING:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Analysis is not being processed"
        )
    
    # Update analysis with results
    update_data = results.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(db_analysis, field, value)
    
    db_analysis.status = AnalysisStatus.COMPLETED
    db_analysis.updated_at = datetime.utcnow()
    
    db.commit()
    db.refresh(db_analysis)
    return db_analysis

def fail_analysis_processing(
    db: Session,
    analysis_id: int,
    error_message: str,
    user_id: int
) -> Analysis:
    """Mark an analysis as failed with an error message"""
    db_analysis = get_analysis(db, analysis_id, user_id)
    
    db_analysis.status = AnalysisStatus.FAILED
    db_analysis.risk_factors = {"error": error_message}
    db_analysis.updated_at = datetime.utcnow()
    
    db.commit()
    db.refresh(db_analysis)
    return db_analysis
