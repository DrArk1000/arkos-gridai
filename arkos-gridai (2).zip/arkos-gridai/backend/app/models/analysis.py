from sqlalchemy import Column, Float, String, Text, Boolean, ForeignKey, JSON
from sqlalchemy.orm import relationship
from .base import Base, TimestampMixin, BaseMixin

class Analysis(Base, BaseMixin, TimestampMixin):
    __tablename__ = "analyses"
    
    # Site information
    site_name = Column(String(255), nullable=True)
    latitude = Column(Float, nullable=False)
    longitude = Column(Float, nullable=False)
    address = Column(Text, nullable=True)
    
    # Analysis status
    status = Column(String(50), default="pending")  # pending, processing, completed, failed
    
    # Analysis parameters
    parameters = Column(JSON, nullable=True)  # Store analysis parameters as JSON
    
    # Results
    risk_score = Column(Float, nullable=True)
    connection_score = Column(Float, nullable=True)
    curtailment_score = Column(Float, nullable=True)
    delay_score = Column(Float, nullable=True)
    
    # Financial metrics
    estimated_cost = Column(Float, nullable=True)
    estimated_revenue = Column(Float, nullable=True)
    payback_period = Column(Float, nullable=True)  # in years
    
    # Risk assessment
    risk_factors = Column(JSON, nullable=True)  # Store detailed risk factors
    
    # Relationships
    owner_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    owner = relationship("User", back_populates="analyses")
    
    def __repr__(self):
        return f"<Analysis {self.id} - {self.site_name or 'Unnamed Site'}>"
