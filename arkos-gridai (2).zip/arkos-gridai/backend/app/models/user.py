from sqlalchemy import Boolean, Column, Integer, String, DateTime
from sqlalchemy.orm import relationship
from .base import Base, TimestampMixin, BaseMixin
from ..core.security import get_password_hash, verify_password

class User(Base, BaseMixin, TimestampMixin):
    __tablename__ = "users"
    
    email = Column(String(255), unique=True, index=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    full_name = Column(String(100), nullable=True)
    is_active = Column(Boolean(), default=True)
    is_superuser = Column(Boolean(), default=False)
    last_login = Column(DateTime, nullable=True)
    
    # Relationships
    analyses = relationship("Analysis", back_populates="owner")
    
    def set_password(self, password: str):
        """Set hashed password"""
        self.hashed_password = get_password_hash(password)
    
    def check_password(self, password: str) -> bool:
        """Verify password"""
        return verify_password(password, self.hashed_password)
    
    def __repr__(self):
        return f"<User {self.email}>"
