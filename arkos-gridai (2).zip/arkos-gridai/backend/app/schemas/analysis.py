from pydantic import BaseModel, Field, validator
from typing import Optional, Dict, Any, List
from datetime import datetime
from enum import Enum

class AnalysisStatus(str, Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"

class AnalysisBase(BaseModel):
    site_name: Optional[str] = Field(None, max_length=255)
    latitude: float = Field(..., ge=-90, le=90, description="Latitude in decimal degrees")
    longitude: float = Field(..., ge=-180, le=180, description="Longitude in decimal degrees")
    address: Optional[str] = None
    parameters: Optional[Dict[str, Any]] = None

class AnalysisCreate(AnalysisBase):
    pass

class AnalysisUpdate(BaseModel):
    site_name: Optional[str] = None
    address: Optional[str] = None
    parameters: Optional[Dict[str, Any]] = None

class AnalysisInDBBase(AnalysisBase):
    id: int
    status: AnalysisStatus = AnalysisStatus.PENDING
    risk_score: Optional[float] = None
    connection_score: Optional[float] = None
    curtailment_score: Optional[float] = None
    delay_score: Optional[float] = None
    estimated_cost: Optional[float] = None
    estimated_revenue: Optional[float] = None
    payback_period: Optional[float] = None
    risk_factors: Optional[Dict[str, Any]] = None
    created_at: datetime
    updated_at: datetime
    owner_id: int

    class Config:
        from_attributes = True

class Analysis(AnalysisInDBBase):
    pass

class AnalysisResults(BaseModel):
    risk_score: float
    connection_score: float
    curtailment_score: float
    delay_score: float
    estimated_cost: float
    estimated_revenue: float
    payback_period: float
    risk_factors: Dict[str, Any]
    report_url: Optional[str] = None

class AnalysisWithResults(Analysis):
    results: Optional[AnalysisResults] = None

class AnalysisPagination(BaseModel):
    items: List[Analysis]
    total: int
    page: int
    size: int
    total_pages: int
