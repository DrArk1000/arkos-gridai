from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from typing import Any

from ....core.database import get_db
from ....schemas.user import UserCreate, User as UserSchema, Token, UserLogin
from ....services import auth as auth_service

router = APIRouter()

@router.post("/register", response_model=UserSchema, status_code=status.HTTP_201_CREATED)
def register_user(
    user_in: UserCreate,
    db: Session = Depends(get_db)
) -> Any:
    """
    Register a new user
    """
    user = auth_service.get_user_by_email(db, email=user_in.email)
    if user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="The user with this email already exists"
        )
    
    user = auth_service.create_user(db, user_in)
    return user

@router.post("/login", response_model=Token)
async def login(
    form_data: OAuth2PasswordRequestForm = Depends(),
    db: Session = Depends(get_db)
) -> Any:
    """
    OAuth2 compatible token login, get an access token for future requests
    """
    user = auth_service.authenticate_user(
        db, email=form_data.username, password=form_data.password
    )
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    # Update last login time
    user.last_login = datetime.utcnow()
    db.commit()
    db.refresh(user)
    
    access_token = auth_service.create_access_token(user)
    return {"access_token": access_token, "token_type": "bearer"}

@router.get("/me", response_model=UserSchema)
async def read_users_me(
    current_user: UserSchema = Depends(auth_service.get_current_active_user)
) -> Any:
    """
    Get current user information
    """
    return current_user

@router.post("/password-recovery/{email}")
async def recover_password(email: str, db: Session = Depends(get_db)) -> Any:
    """
    Password Recovery
    """
    user = auth_service.get_user_by_email(db, email=email)
    if not user:
        # Don't reveal that the user doesn't exist
        return {"message": "If this email is registered, you will receive a password reset link"}
    
    # TODO: Implement password recovery email
    return {"message": "Password recovery email sent"}

@router.post("/reset-password/")
async def reset_password(
    token: str,
    new_password: str,
    db: Session = Depends(get_db)
) -> Any:
    """
    Reset password
    """
    # TODO: Implement password reset logic
    return {"message": "Password updated successfully"}
