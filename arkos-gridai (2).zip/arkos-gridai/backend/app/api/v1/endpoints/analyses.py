from fastapi import APIRouter, Depends, HTTPException, status, Query, BackgroundTasks
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime

from ....core.database import get_db
from ....models.user import User
from ....schemas.analysis import (
    AnalysisCreate, AnalysisUpdate, Analysis as AnalysisSchema,
    AnalysisStatus, AnalysisResults, AnalysisPagination
)
from ....services import analysis as analysis_service
from ....services import auth as auth_service
from ....core.worker import process_analysis_task

router = APIRouter()

@router.get("/", response_model=AnalysisPagination)
def list_analyses(
    skip: int = 0,
    limit: int = 100,
    status: Optional[AnalysisStatus] = None,
    search: Optional[str] = None,
    current_user: User = Depends(auth_service.get_current_active_user),
    db: Session = Depends(get_db)
) -> Any:
    """
    List all analyses for the current user with optional filtering
    """
    return analysis_service.get_analyses(
        db=db,
        user_id=current_user.id,
        skip=skip,
        limit=limit,
        status=status,
        search=search
    )

@router.post("/", response_model=AnalysisSchema, status_code=status.HTTP_201_CREATED)
def create_analysis(
    analysis_in: AnalysisCreate,
    background_tasks: BackgroundTasks,
    current_user: User = Depends(auth_service.get_current_active_user),
    db: Session = Depends(get_db)
) -> Any:
    """
    Create a new analysis
    """
    analysis = analysis_service.create_analysis(
        db=db,
        analysis_data=analysis_in,
        user_id=current_user.id
    )
    
    # Add background task to process the analysis
    background_tasks.add_task(
        process_analysis_task,
        analysis_id=analysis.id,
        user_id=current_user.id
    )
    
    return analysis

@router.get("/{analysis_id}", response_model=AnalysisSchema)
def get_analysis(
    analysis_id: int,
    current_user: User = Depends(auth_service.get_current_active_user),
    db: Session = Depends(get_db)
) -> Any:
    """
    Get analysis by ID
    """
    return analysis_service.get_analysis(
        db=db,
        analysis_id=analysis_id,
        user_id=current_user.id
    )

@router.put("/{analysis_id}", response_model=AnalysisSchema)
def update_analysis(
    analysis_id: int,
    analysis_in: AnalysisUpdate,
    current_user: User = Depends(auth_service.get_current_active_user),
    db: Session = Depends(get_db)
) -> Any:
    """
    Update an analysis
    """
    return analysis_service.update_analysis(
        db=db,
        analysis_id=analysis_id,
        analysis_data=analysis_in,
        user_id=current_user.id
    )

@router.delete("/{analysis_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_analysis(
    analysis_id: int,
    current_user: User = Depends(auth_service.get_current_active_user),
    db: Session = Depends(get_db)
) -> None:
    """
    Delete an analysis
    """
    analysis_service.delete_analysis(
        db=db,
        analysis_id=analysis_id,
        user_id=current_user.id
    )
    return None

@router.post("/{analysis_id}/process", response_model=AnalysisSchema)
def process_analysis(
    analysis_id: int,
    background_tasks: BackgroundTasks,
    current_user: User = Depends(auth_service.get_current_active_user),
    db: Session = Depends(get_db)
) -> Any:
    """
    Manually trigger processing of an analysis
    """
    analysis = analysis_service.get_analysis(
        db=db,
        analysis_id=analysis_id,
        user_id=current_user.id
    )
    
    if analysis.status != AnalysisStatus.PENDING:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Analysis is not in a pending state"
        )
    
    # Mark as processing
    analysis = analysis_service.start_analysis_processing(
        db=db,
        analysis_id=analysis_id,
        user_id=current_user.id
    )
    
    # Add background task to process the analysis
    background_tasks.add_task(
        process_analysis_task,
        analysis_id=analysis.id,
        user_id=current_user.id
    )
    
    return analysis

@router.get("/{analysis_id}/report")
def get_analysis_report(
    analysis_id: int,
    current_user: User = Depends(auth_service.get_current_active_user),
    db: Session = Depends(get_db)
) -> Any:
    """
    Get a PDF report for an analysis
    """
    analysis = analysis_service.get_analysis(
        db=db,
        analysis_id=analysis_id,
        user_id=current_user.id
    )
    
    if analysis.status != AnalysisStatus.COMPLETED:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Analysis is not completed"
        )
    
    # TODO: Generate and return PDF report
    # For now, return a placeholder
    return {"message": "Report generation will be implemented soon"}
