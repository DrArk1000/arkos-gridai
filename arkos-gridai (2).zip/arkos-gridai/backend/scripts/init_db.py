import logging
import sys
from pathlib import Path

# Add the parent directory to the path so we can import app modules
sys.path.append(str(Path(__file__).parent.parent))

from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.database import engine, Base
from app.models.user import User
from app.core.security import get_password_hash

def init_db(db: Session) -> None:
    """Initialize the database with default data"""
    # Create all tables
    Base.metadata.create_all(bind=engine)
    
    # Create default admin user if it doesn't exist
    admin = db.query(User).filter(User.email == settings.FIRST_SUPERUSER).first()
    if not admin:
        admin_user = User(
            email=settings.FIRST_SUPERUSER,
            hashed_password=get_password_hash(settings.FIRST_SUPERUSER_PASSWORD),
            full_name="Admin",
            is_superuser=True,
            is_active=True,
        )
        db.add(admin_user)
        db.commit()
        print("Created admin user:", admin_user.email)
    else:
        print("Admin user already exists:", admin.email)

if __name__ == "__main__":
    from app.core.database import SessionLocal
    
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    
    db = SessionLocal()
    try:
        init_db(db)
        logger.info("Database initialized successfully")
    except Exception as e:
        logger.error(f"Error initializing database: {e}")
        sys.exit(1)
    finally:
        db.close()
