import type { ReactNode } from "react"
import { cn } from "@/lib/utils"

interface GlassPanelProps {
  children: ReactNode
  className?: string
  glow?: boolean
  hover?: boolean
}

export function GlassPanel({ children, className, glow = false, hover = false }: GlassPanelProps) {
  return (
    <div
      className={cn(
        "backdrop-blur-md bg-arkos-glass-bg border border-arkos-glass-border rounded-lg",
        glow && "shadow-lg shadow-arkos-accent/20",
        hover && "hover:border-arkos-accent/40 hover:shadow-arkos-accent/30 transition-all duration-300",
        className,
      )}
    >
      {children}
    </div>
  )
}
