"use client"

import { cn } from "@/lib/utils"

interface StatusIndicatorProps {
  status: "online" | "warning" | "error" | "processing"
  label?: string
  size?: "sm" | "md" | "lg"
  animate?: boolean
}

export function StatusIndicator({ status, label, size = "md", animate = true }: StatusIndicatorProps) {
  const colors = {
    online: "bg-arkos-success",
    warning: "bg-arkos-warning",
    error: "bg-arkos-danger",
    processing: "bg-arkos-accent",
  }

  const sizes = {
    sm: "w-2 h-2",
    md: "w-3 h-3",
    lg: "w-4 h-4",
  }

  return (
    <div className="flex items-center space-x-2">
      <div className={cn("rounded-full", colors[status], sizes[size], animate && "animate-breathe")} />
      {label && <span className="text-arkos-text-secondary text-sm">{label}</span>}
    </div>
  )
}
