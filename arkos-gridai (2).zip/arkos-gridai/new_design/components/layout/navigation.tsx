"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import {
  LayoutDashboard,
  Search,
  FileText,
  TrendingUp,
  Shield,
  Calculator,
  Database,
  Settings,
  Command,
} from "lucide-react"

const navigation = [
  { name: "Command Center", href: "/dashboard", icon: LayoutDashboard },
  { name: "Site Analysis", href: "/analyze", icon: Search },
  { name: "Intelligence Reports", href: "/reports", icon: FileText },
  { name: "Market Surveillance", href: "/market", icon: TrendingUp },
  { name: "Risk Command", href: "/risk", icon: Shield },
  { name: "Financial Modeling", href: "/finance", icon: Calculator },
  { name: "Data Nexus", href: "/data", icon: Database },
  { name: "Settings Lab", href: "/settings", icon: Settings },
]

export function Navigation() {
  const pathname = usePathname()
  const [commandOpen, setCommandOpen] = useState(false)

  return (
    <>
      <nav className="fixed left-0 top-0 h-full w-64 bg-arkos-secondary border-r border-arkos-border-subtle backdrop-blur-md z-40">
        <div className="p-6">
          {/* Logo */}
          <div className="flex items-center space-x-3 mb-8">
            <div className="w-8 h-8 bg-gradient-to-br from-arkos-accent to-arkos-success rounded-lg flex items-center justify-center">
              <div className="w-4 h-4 border-2 border-white rounded-sm transform rotate-45"></div>
            </div>
            <div>
              <div className="text-arkos-text-primary font-bold text-lg">Arkos</div>
              <div className="text-arkos-text-secondary text-xs">Grid Intelligence</div>
            </div>
          </div>

          {/* Command Palette Trigger */}
          <button
            onClick={() => setCommandOpen(true)}
            className="w-full mb-6 p-3 bg-arkos-glass-bg border border-arkos-glass-border rounded-lg text-left text-arkos-text-secondary hover:border-arkos-accent/40 transition-all duration-200 flex items-center space-x-2"
          >
            <Command className="w-4 h-4" />
            <span>Search commands...</span>
            <div className="ml-auto text-xs bg-arkos-border-subtle px-2 py-1 rounded">⌘K</div>
          </button>

          {/* Navigation Links */}
          <div className="space-y-2">
            {navigation.map((item) => {
              const isActive = pathname === item.href
              return (
                <Link
                  key={item.name}
                  href={item.href}
                  className={cn(
                    "flex items-center space-x-3 px-3 py-2 rounded-lg transition-all duration-200",
                    isActive
                      ? "bg-arkos-accent/20 text-arkos-accent border border-arkos-accent/30"
                      : "text-arkos-text-secondary hover:text-arkos-text-primary hover:bg-arkos-glass-bg",
                  )}
                >
                  <item.icon className="w-5 h-5" />
                  <span className="text-sm font-medium">{item.name}</span>
                </Link>
              )
            })}
          </div>
        </div>

        {/* Status Footer */}
        <div className="absolute bottom-0 left-0 right-0 p-6 border-t border-arkos-border-subtle">
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-arkos-text-secondary">System Status</span>
              <div className="flex items-center space-x-1">
                <div className="w-2 h-2 bg-arkos-success rounded-full animate-breathe"></div>
                <span className="text-arkos-success">Operational</span>
              </div>
            </div>
            <div className="text-xs text-arkos-text-muted">
              Grid Data: <span className="text-arkos-success">Live</span> • API:{" "}
              <span className="text-arkos-success">99.9%</span>
            </div>
          </div>
        </div>
      </nav>
    </>
  )
}
