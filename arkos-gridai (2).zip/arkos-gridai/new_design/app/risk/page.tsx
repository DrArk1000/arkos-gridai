"use client"

import { useState } from "react"
import { GlassPanel } from "@/components/ui/glass-panel"
import { AnimatedCounter } from "@/components/ui/animated-counter"
import { StatusIndicator } from "@/components/ui/status-indicator"
import {
  Shield,
  AlertTriangle,
  TrendingUp,
  Clock,
  MapPin,
  Zap,
  FileText,
  Settings,
  Target,
  Activity,
} from "lucide-react"

interface RiskIndicator {
  id: string
  location: { lat: number; lon: number }
  type: "regulatory" | "technical" | "financial" | "environmental"
  severity: "low" | "medium" | "high" | "critical"
  title: string
  description: string
  impact: number
  timeline: string
}

interface ScenarioResult {
  name: string
  probability: number
  impact: number
  irr: number
  timeline: number
}

export default function RiskPage() {
  const [riskIndicators] = useState<RiskIndicator[]>([
    {
      id: "RISK-001",
      location: { lat: -33.8688, lon: 151.2093 },
      type: "regulatory",
      severity: "high",
      title: "AEMO Rule Change Proposal",
      description: "New transmission access arrangements may affect connection rights",
      impact: 8.5,
      timeline: "Q2 2024",
    },
    {
      id: "RISK-002",
      location: { lat: -37.8136, lon: 144.9631 },
      type: "technical",
      severity: "medium",
      title: "Grid Stability Concerns",
      description: "Increasing renewable penetration causing voltage fluctuations",
      impact: 6.2,
      timeline: "Ongoing",
    },
    {
      id: "RISK-003",
      location: { lat: -27.4698, lon: 153.0251 },
      type: "financial",
      severity: "critical",
      title: "Curtailment Risk Escalation",
      description: "Network congestion leading to increased generation curtailment",
      impact: 9.1,
      timeline: "Immediate",
    },
    {
      id: "RISK-004",
      location: { lat: -34.9285, lon: 138.6007 },
      type: "environmental",
      severity: "low",
      title: "Environmental Assessment Delay",
      description: "Extended consultation period for protected species habitat",
      impact: 3.7,
      timeline: "Q3 2024",
    },
  ])

  const [scenarioResults] = useState<ScenarioResult[]>([
    { name: "Base Case", probability: 60, impact: 0, irr: 12.4, timeline: 18 },
    { name: "Delayed Connection", probability: 25, impact: -15, irr: 9.8, timeline: 24 },
    { name: "Regulatory Change", probability: 10, impact: -25, irr: 7.2, timeline: 30 },
    { name: "Grid Constraint", probability: 5, impact: -40, irr: 4.1, timeline: 36 },
  ])

  const [selectedRisk, setSelectedRisk] = useState<RiskIndicator | null>(null)

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "low":
        return "text-arkos-success bg-arkos-success/10 border-arkos-success/20"
      case "medium":
        return "text-arkos-warning bg-arkos-warning/10 border-arkos-warning/20"
      case "high":
        return "text-arkos-danger bg-arkos-danger/10 border-arkos-danger/20"
      case "critical":
        return "text-red-400 bg-red-500/10 border-red-500/20 animate-pulse"
      default:
        return "text-arkos-text-secondary"
    }
  }

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "regulatory":
        return <FileText className="w-4 h-4" />
      case "technical":
        return <Zap className="w-4 h-4" />
      case "financial":
        return <TrendingUp className="w-4 h-4" />
      case "environmental":
        return <Shield className="w-4 h-4" />
      default:
        return <AlertTriangle className="w-4 h-4" />
    }
  }

  const getTypeColor = (type: string) => {
    switch (type) {
      case "regulatory":
        return "text-arkos-accent"
      case "technical":
        return "text-arkos-warning"
      case "financial":
        return "text-arkos-success"
      case "environmental":
        return "text-arkos-text-primary"
      default:
        return "text-arkos-text-secondary"
    }
  }

  return (
    <div className="min-h-screen bg-arkos-primary p-6 ml-64">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-arkos-text-primary mb-2">Risk Command Center</h1>
          <p className="text-arkos-text-secondary">
            Advanced threat detection and scenario modeling for grid infrastructure
          </p>
        </div>

        {/* Risk Overview Dashboard */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <GlassPanel className="p-6" glow>
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-red-500/20 rounded-lg flex items-center justify-center">
                <AlertTriangle className="w-6 h-6 text-red-400" />
              </div>
              <div>
                <div className="text-2xl font-mono font-bold text-arkos-text-primary">
                  <AnimatedCounter value={4} />
                </div>
                <div className="text-arkos-text-secondary text-sm">Active Threats</div>
              </div>
            </div>
          </GlassPanel>

          <GlassPanel className="p-6" glow>
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-arkos-warning/20 rounded-lg flex items-center justify-center">
                <Target className="w-6 h-6 text-arkos-warning" />
              </div>
              <div>
                <div className="text-2xl font-mono font-bold text-arkos-text-primary">
                  <AnimatedCounter value={7.2} suffix="/10" />
                </div>
                <div className="text-arkos-text-secondary text-sm">Risk Score</div>
              </div>
            </div>
          </GlassPanel>

          <GlassPanel className="p-6" glow>
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-arkos-accent/20 rounded-lg flex items-center justify-center">
                <Clock className="w-6 h-6 text-arkos-accent" />
              </div>
              <div>
                <div className="text-2xl font-mono font-bold text-arkos-text-primary">
                  <AnimatedCounter value={23} suffix=" days" />
                </div>
                <div className="text-arkos-text-secondary text-sm">Avg Response Time</div>
              </div>
            </div>
          </GlassPanel>

          <GlassPanel className="p-6" glow>
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-arkos-success/20 rounded-lg flex items-center justify-center">
                <Shield className="w-6 h-6 text-arkos-success" />
              </div>
              <div>
                <div className="text-2xl font-mono font-bold text-arkos-text-primary">
                  <AnimatedCounter value={89} suffix="%" />
                </div>
                <div className="text-arkos-text-secondary text-sm">Mitigation Rate</div>
              </div>
            </div>
          </GlassPanel>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Central Threat Map */}
          <div className="lg:col-span-2">
            <GlassPanel className="p-6 h-96" glow>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold text-arkos-text-primary flex items-center space-x-2">
                  <MapPin className="w-5 h-5 text-arkos-danger" />
                  <span>Threat Intelligence Map</span>
                </h2>
                <StatusIndicator status="warning" label="4 Active Threats" />
              </div>

              {/* Simplified Map with Risk Indicators */}
              <div className="relative h-64 bg-arkos-secondary/30 rounded-lg border border-arkos-border-subtle overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-arkos-accent/10 via-arkos-warning/10 to-arkos-danger/10"></div>

                {/* Risk Indicators on Map */}
                {riskIndicators.map((risk, index) => (
                  <div
                    key={risk.id}
                    onClick={() => setSelectedRisk(risk)}
                    className={`absolute w-4 h-4 rounded-full cursor-pointer transition-all duration-300 hover:scale-150 ${
                      risk.severity === "critical"
                        ? "bg-red-500 animate-pulse shadow-lg shadow-red-500/50"
                        : risk.severity === "high"
                          ? "bg-arkos-danger shadow-lg shadow-arkos-danger/30"
                          : risk.severity === "medium"
                            ? "bg-arkos-warning"
                            : "bg-arkos-success"
                    }`}
                    style={{
                      top: `${20 + index * 15}%`,
                      left: `${25 + index * 20}%`,
                    }}
                  >
                    <div
                      className={`absolute inset-0 rounded-full animate-ping ${
                        risk.severity === "critical"
                          ? "bg-red-500"
                          : risk.severity === "high"
                            ? "bg-arkos-danger"
                            : risk.severity === "medium"
                              ? "bg-arkos-warning"
                              : "bg-arkos-success"
                      }`}
                    ></div>
                  </div>
                ))}

                {/* Map Legend */}
                <div className="absolute bottom-4 left-4 space-y-1">
                  <div className="flex items-center space-x-2 text-xs">
                    <div className="w-2 h-2 bg-arkos-success rounded-full"></div>
                    <span className="text-arkos-text-secondary">Low Risk</span>
                  </div>
                  <div className="flex items-center space-x-2 text-xs">
                    <div className="w-2 h-2 bg-arkos-warning rounded-full"></div>
                    <span className="text-arkos-text-secondary">Medium Risk</span>
                  </div>
                  <div className="flex items-center space-x-2 text-xs">
                    <div className="w-2 h-2 bg-arkos-danger rounded-full"></div>
                    <span className="text-arkos-text-secondary">High Risk</span>
                  </div>
                  <div className="flex items-center space-x-2 text-xs">
                    <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                    <span className="text-arkos-text-secondary">Critical Risk</span>
                  </div>
                </div>
              </div>
            </GlassPanel>
          </div>

          {/* Risk Detail Panel */}
          <div className="lg:col-span-1">
            <GlassPanel className="p-6 h-96" glow>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold text-arkos-text-primary">Risk Details</h2>
              </div>

              {selectedRisk ? (
                <div className="space-y-4">
                  <div>
                    <div className="flex items-center space-x-2 mb-2">
                      <div
                        className={`w-8 h-8 rounded-lg flex items-center justify-center ${getTypeColor(selectedRisk.type)} bg-current/10`}
                      >
                        {getTypeIcon(selectedRisk.type)}
                      </div>
                      <div>
                        <div className="text-arkos-text-primary font-medium">{selectedRisk.title}</div>
                        <div className="text-arkos-text-secondary text-xs">{selectedRisk.id}</div>
                      </div>
                    </div>
                    <div
                      className={`inline-flex px-2 py-1 rounded-full text-xs border ${getSeverityColor(selectedRisk.severity)}`}
                    >
                      {selectedRisk.severity.toUpperCase()} SEVERITY
                    </div>
                  </div>

                  <div>
                    <div className="text-arkos-text-secondary text-sm mb-1">Description</div>
                    <div className="text-arkos-text-primary text-sm leading-relaxed">{selectedRisk.description}</div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <div className="text-arkos-text-secondary text-sm mb-1">Impact Score</div>
                      <div className="text-xl font-mono font-bold text-arkos-danger">{selectedRisk.impact}/10</div>
                    </div>
                    <div>
                      <div className="text-arkos-text-secondary text-sm mb-1">Timeline</div>
                      <div className="text-arkos-text-primary font-medium">{selectedRisk.timeline}</div>
                    </div>
                  </div>

                  <div className="pt-4 border-t border-arkos-border-subtle space-y-2">
                    <button className="w-full bg-gradient-to-r from-arkos-accent to-arkos-success px-4 py-2 rounded-lg text-white font-medium text-sm hover:shadow-lg transition-all duration-200">
                      Create Mitigation Plan
                    </button>
                    <button className="w-full px-4 py-2 border border-arkos-border-prominent text-arkos-text-primary rounded-lg hover:border-arkos-accent/50 transition-all duration-200 text-sm">
                      View Full Analysis
                    </button>
                  </div>
                </div>
              ) : (
                <div className="flex items-center justify-center h-full text-center">
                  <div className="space-y-4">
                    <div className="w-16 h-16 bg-arkos-danger/20 rounded-full flex items-center justify-center mx-auto">
                      <Target className="w-8 h-8 text-arkos-danger" />
                    </div>
                    <div>
                      <div className="text-arkos-text-primary font-medium mb-2">Select a Risk</div>
                      <div className="text-arkos-text-secondary text-sm">
                        Click on a threat indicator on the map to view detailed analysis
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </GlassPanel>
          </div>
        </div>

        {/* Scenario Simulator & Timeline */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
          {/* Scenario Simulator */}
          <GlassPanel className="p-6" glow>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-arkos-text-primary flex items-center space-x-2">
                <Activity className="w-5 h-5 text-arkos-accent" />
                <span>Scenario Simulator</span>
              </h2>
              <div className="text-arkos-text-secondary text-sm">Parallel Universe Analysis</div>
            </div>

            <div className="space-y-3">
              {scenarioResults.map((scenario, index) => (
                <div
                  key={scenario.name}
                  className="bg-arkos-secondary/30 border border-arkos-border-subtle rounded-lg p-4"
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-3">
                      <div className="text-arkos-text-primary font-medium">{scenario.name}</div>
                      <div className="text-arkos-text-secondary text-sm">{scenario.probability}% probability</div>
                    </div>
                    <div
                      className={`text-sm font-mono ${
                        scenario.impact >= 0 ? "text-arkos-success" : "text-arkos-danger"
                      }`}
                    >
                      {scenario.impact >= 0 ? "+" : ""}
                      {scenario.impact}%
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-4 text-sm">
                    <div>
                      <div className="text-arkos-text-secondary text-xs">IRR</div>
                      <div className="text-arkos-text-primary font-mono">{scenario.irr}%</div>
                    </div>
                    <div>
                      <div className="text-arkos-text-secondary text-xs">Timeline</div>
                      <div className="text-arkos-text-primary font-mono">{scenario.timeline} months</div>
                    </div>
                  </div>

                  {/* Probability Bar */}
                  <div className="mt-3">
                    <div className="w-full bg-arkos-border-subtle rounded-full h-1">
                      <div
                        className="bg-gradient-to-r from-arkos-accent to-arkos-success h-1 rounded-full transition-all duration-500"
                        style={{ width: `${scenario.probability}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </GlassPanel>

          {/* Regulatory Timeline */}
          <GlassPanel className="p-6" glow>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-arkos-text-primary flex items-center space-x-2">
                <Clock className="w-5 h-5 text-arkos-warning" />
                <span>Regulatory Timeline</span>
              </h2>
              <div className="text-arkos-text-secondary text-sm">Upcoming Changes</div>
            </div>

            <div className="space-y-4">
              <div className="flex items-start space-x-4">
                <div className="flex flex-col items-center">
                  <div className="w-3 h-3 bg-arkos-danger rounded-full"></div>
                  <div className="w-0.5 h-12 bg-arkos-border-subtle"></div>
                </div>
                <div className="flex-1">
                  <div className="text-arkos-text-primary font-medium text-sm">AEMO Rule Change</div>
                  <div className="text-arkos-text-secondary text-xs mb-1">Q2 2024</div>
                  <div className="text-arkos-text-secondary text-xs">
                    Transmission access arrangements reform affecting connection rights
                  </div>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="flex flex-col items-center">
                  <div className="w-3 h-3 bg-arkos-warning rounded-full"></div>
                  <div className="w-0.5 h-12 bg-arkos-border-subtle"></div>
                </div>
                <div className="flex-1">
                  <div className="text-arkos-text-primary font-medium text-sm">ESB Market Review</div>
                  <div className="text-arkos-text-secondary text-xs mb-1">Q3 2024</div>
                  <div className="text-arkos-text-secondary text-xs">
                    Energy Security Board reviewing capacity mechanisms
                  </div>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="flex flex-col items-center">
                  <div className="w-3 h-3 bg-arkos-accent rounded-full"></div>
                  <div className="w-0.5 h-12 bg-arkos-border-subtle"></div>
                </div>
                <div className="flex-1">
                  <div className="text-arkos-text-primary font-medium text-sm">REZ Implementation</div>
                  <div className="text-arkos-text-secondary text-xs mb-1">Q4 2024</div>
                  <div className="text-arkos-text-secondary text-xs">
                    Renewable Energy Zone framework rollout across states
                  </div>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="flex flex-col items-center">
                  <div className="w-3 h-3 bg-arkos-success rounded-full"></div>
                </div>
                <div className="flex-1">
                  <div className="text-arkos-text-primary font-medium text-sm">Grid Code Updates</div>
                  <div className="text-arkos-text-secondary text-xs mb-1">Q1 2025</div>
                  <div className="text-arkos-text-secondary text-xs">
                    Technical standards for grid-forming inverters
                  </div>
                </div>
              </div>
            </div>
          </GlassPanel>
        </div>

        {/* Alert Configuration Matrix */}
        <div className="mt-6">
          <GlassPanel className="p-6" glow>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-arkos-text-primary flex items-center space-x-2">
                <Settings className="w-5 h-5 text-arkos-accent" />
                <span>Alert Configuration Matrix</span>
              </h2>
              <button className="bg-gradient-to-r from-arkos-accent to-arkos-success px-4 py-2 rounded-lg text-white font-medium text-sm hover:shadow-lg transition-all duration-200">
                Configure Alerts
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="bg-arkos-secondary/30 border border-arkos-border-subtle rounded-lg p-4">
                <div className="flex items-center space-x-2 mb-3">
                  <FileText className="w-5 h-5 text-arkos-accent" />
                  <span className="text-arkos-text-primary font-medium">Regulatory</span>
                </div>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center justify-between">
                    <span className="text-arkos-text-secondary">Rule Changes</span>
                    <StatusIndicator status="online" size="sm" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-arkos-text-secondary">Policy Updates</span>
                    <StatusIndicator status="online" size="sm" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-arkos-text-secondary">Consultation</span>
                    <StatusIndicator status="warning" size="sm" />
                  </div>
                </div>
              </div>

              <div className="bg-arkos-secondary/30 border border-arkos-border-subtle rounded-lg p-4">
                <div className="flex items-center space-x-2 mb-3">
                  <Zap className="w-5 h-5 text-arkos-warning" />
                  <span className="text-arkos-text-primary font-medium">Technical</span>
                </div>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center justify-between">
                    <span className="text-arkos-text-secondary">Grid Stability</span>
                    <StatusIndicator status="warning" size="sm" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-arkos-text-secondary">Voltage Issues</span>
                    <StatusIndicator status="online" size="sm" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-arkos-text-secondary">Frequency</span>
                    <StatusIndicator status="online" size="sm" />
                  </div>
                </div>
              </div>

              <div className="bg-arkos-secondary/30 border border-arkos-border-subtle rounded-lg p-4">
                <div className="flex items-center space-x-2 mb-3">
                  <TrendingUp className="w-5 h-5 text-arkos-success" />
                  <span className="text-arkos-text-primary font-medium">Financial</span>
                </div>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center justify-between">
                    <span className="text-arkos-text-secondary">Price Volatility</span>
                    <StatusIndicator status="error" size="sm" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-arkos-text-secondary">Curtailment</span>
                    <StatusIndicator status="warning" size="sm" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-arkos-text-secondary">Revenue Risk</span>
                    <StatusIndicator status="online" size="sm" />
                  </div>
                </div>
              </div>

              <div className="bg-arkos-secondary/30 border border-arkos-border-subtle rounded-lg p-4">
                <div className="flex items-center space-x-2 mb-3">
                  <Shield className="w-5 h-5 text-arkos-text-primary" />
                  <span className="text-arkos-text-primary font-medium">Environmental</span>
                </div>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center justify-between">
                    <span className="text-arkos-text-secondary">Permits</span>
                    <StatusIndicator status="online" size="sm" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-arkos-text-secondary">Compliance</span>
                    <StatusIndicator status="online" size="sm" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-arkos-text-secondary">Impact Studies</span>
                    <StatusIndicator status="warning" size="sm" />
                  </div>
                </div>
              </div>
            </div>
          </GlassPanel>
        </div>
      </div>
    </div>
  )
}
