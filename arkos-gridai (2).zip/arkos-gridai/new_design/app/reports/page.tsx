"use client"

import { useState } from "react"
import { GlassPanel } from "@/components/ui/glass-panel"
import { AnimatedCounter } from "@/components/ui/animated-counter"
import { StatusIndicator } from "@/components/ui/status-indicator"
import { FileText, Download, Share, Eye, Calendar, Search, BarChart3, TrendingUp, Shield, Zap } from "lucide-react"

interface Report {
  id: string
  title: string
  type: "bankability" | "risk" | "market" | "technical"
  status: "completed" | "processing" | "draft"
  date: string
  score?: number
  size: string
}

export default function ReportsPage() {
  const [reports] = useState<Report[]>([
    {
      id: "RPT-2024-001",
      title: "Solar Farm Alpha - Grid Connection Analysis",
      type: "bankability",
      status: "completed",
      date: "2024-01-15",
      score: 8.7,
      size: "2.4 MB",
    },
    {
      id: "RPT-2024-002",
      title: "Wind Park Beta - Risk Assessment",
      type: "risk",
      status: "completed",
      date: "2024-01-14",
      score: 7.2,
      size: "1.8 MB",
    },
    {
      id: "RPT-2024-003",
      title: "Battery Storage Gamma - Market Analysis",
      type: "market",
      status: "processing",
      date: "2024-01-13",
      size: "Processing...",
    },
    {
      id: "RPT-2024-004",
      title: "Hybrid Project Delta - Technical Review",
      type: "technical",
      status: "draft",
      date: "2024-01-12",
      size: "Draft",
    },
  ])

  const [selectedReport, setSelectedReport] = useState<Report | null>(null)
  const [searchTerm, setSearchTerm] = useState("")
  const [filterType, setFilterType] = useState<string>("all")

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "bankability":
        return <BarChart3 className="w-4 h-4" />
      case "risk":
        return <Shield className="w-4 h-4" />
      case "market":
        return <TrendingUp className="w-4 h-4" />
      case "technical":
        return <Zap className="w-4 h-4" />
      default:
        return <FileText className="w-4 h-4" />
    }
  }

  const getTypeColor = (type: string) => {
    switch (type) {
      case "bankability":
        return "text-arkos-success"
      case "risk":
        return "text-arkos-warning"
      case "market":
        return "text-arkos-accent"
      case "technical":
        return "text-arkos-text-primary"
      default:
        return "text-arkos-text-secondary"
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "text-arkos-success bg-arkos-success/10 border-arkos-success/20"
      case "processing":
        return "text-arkos-accent bg-arkos-accent/10 border-arkos-accent/20"
      case "draft":
        return "text-arkos-warning bg-arkos-warning/10 border-arkos-warning/20"
      default:
        return "text-arkos-text-secondary bg-arkos-border-subtle/10 border-arkos-border-subtle/20"
    }
  }

  const filteredReports = reports.filter((report) => {
    const matchesSearch = report.title.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesFilter = filterType === "all" || report.type === filterType
    return matchesSearch && matchesFilter
  })

  return (
    <div className="min-h-screen bg-arkos-primary p-6 ml-64">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-arkos-text-primary mb-2">Intelligence Reports</h1>
          <p className="text-arkos-text-secondary">Digital vault of grid analysis reports and insights</p>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <GlassPanel className="p-6" glow>
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-arkos-success/20 rounded-lg flex items-center justify-center">
                <FileText className="w-6 h-6 text-arkos-success" />
              </div>
              <div>
                <div className="text-2xl font-mono font-bold text-arkos-text-primary">
                  <AnimatedCounter value={247} />
                </div>
                <div className="text-arkos-text-secondary text-sm">Total Reports</div>
              </div>
            </div>
          </GlassPanel>

          <GlassPanel className="p-6" glow>
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-arkos-accent/20 rounded-lg flex items-center justify-center">
                <BarChart3 className="w-6 h-6 text-arkos-accent" />
              </div>
              <div>
                <div className="text-2xl font-mono font-bold text-arkos-text-primary">
                  <AnimatedCounter value={89} />
                </div>
                <div className="text-arkos-text-secondary text-sm">Bankability Reports</div>
              </div>
            </div>
          </GlassPanel>

          <GlassPanel className="p-6" glow>
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-arkos-warning/20 rounded-lg flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-arkos-warning" />
              </div>
              <div>
                <div className="text-2xl font-mono font-bold text-arkos-text-primary">
                  <AnimatedCounter value={8.4} suffix="/10" />
                </div>
                <div className="text-arkos-text-secondary text-sm">Avg Score</div>
              </div>
            </div>
          </GlassPanel>

          <GlassPanel className="p-6" glow>
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-arkos-success/20 rounded-lg flex items-center justify-center">
                <Download className="w-6 h-6 text-arkos-success" />
              </div>
              <div>
                <div className="text-2xl font-mono font-bold text-arkos-text-primary">
                  <AnimatedCounter value={1247} />
                </div>
                <div className="text-arkos-text-secondary text-sm">Downloads</div>
              </div>
            </div>
          </GlassPanel>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Reports List */}
          <div className="lg:col-span-2">
            <GlassPanel className="p-6" glow>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold text-arkos-text-primary">Report Archive</h2>
                <div className="flex items-center space-x-3">
                  {/* Search */}
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-arkos-text-secondary" />
                    <input
                      type="text"
                      placeholder="Search reports..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10 pr-4 py-2 bg-arkos-secondary/50 border border-arkos-border-subtle rounded-lg text-arkos-text-primary text-sm focus:border-arkos-accent focus:outline-none w-64"
                    />
                  </div>

                  {/* Filter */}
                  <select
                    value={filterType}
                    onChange={(e) => setFilterType(e.target.value)}
                    className="px-3 py-2 bg-arkos-secondary/50 border border-arkos-border-subtle rounded-lg text-arkos-text-primary text-sm focus:border-arkos-accent focus:outline-none"
                  >
                    <option value="all">All Types</option>
                    <option value="bankability">Bankability</option>
                    <option value="risk">Risk</option>
                    <option value="market">Market</option>
                    <option value="technical">Technical</option>
                  </select>
                </div>
              </div>

              <div className="space-y-3">
                {filteredReports.map((report) => (
                  <div
                    key={report.id}
                    onClick={() => setSelectedReport(report)}
                    className="bg-arkos-secondary/30 border border-arkos-border-subtle rounded-lg p-4 hover:border-arkos-accent/40 hover:bg-arkos-secondary/50 transition-all duration-200 cursor-pointer"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-start space-x-3 flex-1">
                        <div
                          className={`w-10 h-10 rounded-lg flex items-center justify-center ${getTypeColor(report.type)} bg-current/10`}
                        >
                          {getTypeIcon(report.type)}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-1">
                            <h3 className="text-arkos-text-primary font-medium">{report.title}</h3>
                            <span className={`px-2 py-1 rounded-full text-xs border ${getStatusColor(report.status)}`}>
                              {report.status}
                            </span>
                          </div>
                          <div className="flex items-center space-x-4 text-sm text-arkos-text-secondary">
                            <span className="flex items-center space-x-1">
                              <Calendar className="w-3 h-3" />
                              <span>{report.date}</span>
                            </span>
                            <span>{report.id}</span>
                            <span>{report.size}</span>
                            {report.score && (
                              <span className="text-arkos-success font-mono">Score: {report.score}/10</span>
                            )}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <button className="p-2 text-arkos-text-secondary hover:text-arkos-accent transition-colors">
                          <Eye className="w-4 h-4" />
                        </button>
                        <button className="p-2 text-arkos-text-secondary hover:text-arkos-success transition-colors">
                          <Download className="w-4 h-4" />
                        </button>
                        <button className="p-2 text-arkos-text-secondary hover:text-arkos-warning transition-colors">
                          <Share className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </GlassPanel>
          </div>

          {/* Report Preview */}
          <div className="lg:col-span-1">
            <GlassPanel className="p-6 h-full" glow>
              {selectedReport ? (
                <div className="space-y-6">
                  <div>
                    <h3 className="text-lg font-semibold text-arkos-text-primary mb-2">Report Preview</h3>
                    <div className="text-arkos-text-secondary text-sm">{selectedReport.id}</div>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <div className="text-arkos-text-secondary text-sm mb-1">Title</div>
                      <div className="text-arkos-text-primary">{selectedReport.title}</div>
                    </div>

                    <div>
                      <div className="text-arkos-text-secondary text-sm mb-1">Type</div>
                      <div className={`flex items-center space-x-2 ${getTypeColor(selectedReport.type)}`}>
                        {getTypeIcon(selectedReport.type)}
                        <span className="capitalize">{selectedReport.type}</span>
                      </div>
                    </div>

                    <div>
                      <div className="text-arkos-text-secondary text-sm mb-1">Status</div>
                      <StatusIndicator
                        status={
                          selectedReport.status === "completed"
                            ? "online"
                            : selectedReport.status === "processing"
                              ? "processing"
                              : "warning"
                        }
                        label={selectedReport.status}
                      />
                    </div>

                    <div>
                      <div className="text-arkos-text-secondary text-sm mb-1">Generated</div>
                      <div className="text-arkos-text-primary">{selectedReport.date}</div>
                    </div>

                    {selectedReport.score && (
                      <div>
                        <div className="text-arkos-text-secondary text-sm mb-1">Bankability Score</div>
                        <div className="text-2xl font-mono font-bold text-arkos-success">{selectedReport.score}/10</div>
                      </div>
                    )}

                    <div>
                      <div className="text-arkos-text-secondary text-sm mb-1">File Size</div>
                      <div className="text-arkos-text-primary">{selectedReport.size}</div>
                    </div>
                  </div>

                  <div className="space-y-3 pt-4 border-t border-arkos-border-subtle">
                    <button className="w-full bg-gradient-to-r from-arkos-accent to-arkos-success px-4 py-2 rounded-lg text-white font-medium hover:shadow-lg transition-all duration-200 flex items-center justify-center space-x-2">
                      <Eye className="w-4 h-4" />
                      <span>View Report</span>
                    </button>

                    <button className="w-full px-4 py-2 border border-arkos-border-prominent text-arkos-text-primary rounded-lg hover:border-arkos-accent/50 transition-all duration-200 flex items-center justify-center space-x-2">
                      <Download className="w-4 h-4" />
                      <span>Download PDF</span>
                    </button>

                    <button className="w-full px-4 py-2 border border-arkos-border-prominent text-arkos-text-primary rounded-lg hover:border-arkos-accent/50 transition-all duration-200 flex items-center justify-center space-x-2">
                      <Share className="w-4 h-4" />
                      <span>Share Report</span>
                    </button>
                  </div>
                </div>
              ) : (
                <div className="flex items-center justify-center h-full text-center">
                  <div className="space-y-4">
                    <div className="w-16 h-16 bg-arkos-accent/20 rounded-full flex items-center justify-center mx-auto">
                      <FileText className="w-8 h-8 text-arkos-accent" />
                    </div>
                    <div>
                      <div className="text-arkos-text-primary font-medium mb-2">Select a Report</div>
                      <div className="text-arkos-text-secondary text-sm">
                        Choose a report from the list to view details and download options
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </GlassPanel>
          </div>
        </div>

        {/* Report Generation Workshop */}
        <div className="mt-8">
          <GlassPanel className="p-6" glow>
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-lg font-semibold text-arkos-text-primary mb-1">Report Generation Workshop</h3>
                <p className="text-arkos-text-secondary text-sm">Create custom reports with advanced templates</p>
              </div>
              <button className="bg-gradient-to-r from-arkos-accent to-arkos-success px-6 py-2 rounded-lg text-white font-medium hover:shadow-lg transition-all duration-200">
                New Report
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="bg-arkos-secondary/30 border border-arkos-border-subtle rounded-lg p-4 hover:border-arkos-accent/40 transition-all duration-200 cursor-pointer">
                <div className="w-8 h-8 bg-arkos-success/20 rounded-lg flex items-center justify-center mb-3">
                  <BarChart3 className="w-4 h-4 text-arkos-success" />
                </div>
                <div className="text-arkos-text-primary font-medium mb-1">Bankability Template</div>
                <div className="text-arkos-text-secondary text-xs">Comprehensive financial analysis</div>
              </div>

              <div className="bg-arkos-secondary/30 border border-arkos-border-subtle rounded-lg p-4 hover:border-arkos-accent/40 transition-all duration-200 cursor-pointer">
                <div className="w-8 h-8 bg-arkos-warning/20 rounded-lg flex items-center justify-center mb-3">
                  <Shield className="w-4 h-4 text-arkos-warning" />
                </div>
                <div className="text-arkos-text-primary font-medium mb-1">Risk Assessment</div>
                <div className="text-arkos-text-secondary text-xs">Grid connection risk analysis</div>
              </div>

              <div className="bg-arkos-secondary/30 border border-arkos-border-subtle rounded-lg p-4 hover:border-arkos-accent/40 transition-all duration-200 cursor-pointer">
                <div className="w-8 h-8 bg-arkos-accent/20 rounded-lg flex items-center justify-center mb-3">
                  <TrendingUp className="w-4 h-4 text-arkos-accent" />
                </div>
                <div className="text-arkos-text-primary font-medium mb-1">Market Analysis</div>
                <div className="text-arkos-text-secondary text-xs">Regional market insights</div>
              </div>

              <div className="bg-arkos-secondary/30 border border-arkos-border-subtle rounded-lg p-4 hover:border-arkos-accent/40 transition-all duration-200 cursor-pointer">
                <div className="w-8 h-8 bg-arkos-text-primary/20 rounded-lg flex items-center justify-center mb-3">
                  <Zap className="w-4 h-4 text-arkos-text-primary" />
                </div>
                <div className="text-arkos-text-primary font-medium mb-1">Technical Review</div>
                <div className="text-arkos-text-secondary text-xs">Engineering assessment</div>
              </div>
            </div>
          </GlassPanel>
        </div>
      </div>
    </div>
  )
}
