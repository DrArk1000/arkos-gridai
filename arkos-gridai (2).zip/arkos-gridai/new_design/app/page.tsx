"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { AnimatedCounter } from "@/components/ui/animated-counter"
import { GlassPanel } from "@/components/ui/glass-panel"
import { ArrowRight, Zap, Globe, BarChart3 } from "lucide-react"

export default function LandingPage() {
  const [sitesAnalyzed, setSitesAnalyzed] = useState(47832)

  useEffect(() => {
    const interval = setInterval(() => {
      setSitesAnalyzed((prev) => prev + Math.floor(Math.random() * 3) + 1)
    }, 5000)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="min-h-screen bg-arkos-primary relative overflow-hidden">
      {/* Animated Grid Background */}
      <div className="absolute inset-0 bg-grid-pattern bg-grid opacity-30"></div>
      <div className="absolute inset-0 bg-gradient-to-br from-arkos-accent/5 via-transparent to-arkos-success/5"></div>

      {/* Scanning Line Animation */}
      <div className="absolute top-0 left-0 w-1 h-full bg-gradient-to-b from-transparent via-arkos-accent to-transparent animate-grid-scan opacity-60"></div>

      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen px-4">
        {/* Hero Section */}
        <div className="text-center max-w-4xl mx-auto mb-16">
          {/* Logo */}
          <div className="flex items-center justify-center space-x-4 mb-8">
            <div className="w-16 h-16 bg-gradient-to-br from-arkos-accent to-arkos-success rounded-xl flex items-center justify-center animate-float">
              <div className="w-8 h-8 border-3 border-white rounded-lg transform rotate-45"></div>
            </div>
            <div className="text-left">
              <div className="text-4xl font-bold text-arkos-text-primary">Arkos</div>
              <div className="text-arkos-text-secondary">Grid Intelligence Platform</div>
            </div>
          </div>

          {/* Main Headline */}
          <h1 className="text-6xl font-bold text-arkos-text-primary mb-6 leading-tight">
            Grid Intelligence at the
            <span className="bg-gradient-to-r from-arkos-accent to-arkos-success bg-clip-text text-transparent block">
              Speed of Light
            </span>
          </h1>

          <p className="text-xl text-arkos-text-secondary mb-8 leading-relaxed">
            Replace 6-month grid connection studies with AI-powered 5-minute analysis. Make renewable energy projects
            bankable at unprecedented speed.
          </p>

          {/* Real-time Counter */}
          <div className="mb-12">
            <GlassPanel className="inline-block p-6" glow>
              <div className="text-arkos-text-secondary text-sm mb-2">Sites Analyzed Today</div>
              <div className="text-4xl font-mono font-bold text-arkos-accent">
                <AnimatedCounter value={sitesAnalyzed} />
              </div>
            </GlassPanel>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-16">
            <Link
              href="/dashboard"
              className="group bg-gradient-to-r from-arkos-accent to-arkos-success px-8 py-4 rounded-lg text-white font-semibold hover:shadow-lg hover:shadow-arkos-accent/30 transition-all duration-300 flex items-center space-x-2"
            >
              <span>Enter Command Center</span>
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Link>
            <Link
              href="/analyze"
              className="px-8 py-4 border border-arkos-border-prominent text-arkos-text-primary rounded-lg hover:border-arkos-accent/50 hover:bg-arkos-glass-bg transition-all duration-300"
            >
              Start Analysis
            </Link>
          </div>
        </div>

        {/* Feature Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-6xl mx-auto">
          <GlassPanel className="p-6 text-center" hover>
            <div className="w-12 h-12 bg-arkos-accent/20 rounded-lg flex items-center justify-center mx-auto mb-4">
              <Zap className="w-6 h-6 text-arkos-accent" />
            </div>
            <h3 className="text-lg font-semibold text-arkos-text-primary mb-2">Lightning Fast</h3>
            <p className="text-arkos-text-secondary text-sm">
              5-minute grid connection analysis replacing traditional 6-month studies
            </p>
          </GlassPanel>

          <GlassPanel className="p-6 text-center" hover>
            <div className="w-12 h-12 bg-arkos-success/20 rounded-lg flex items-center justify-center mx-auto mb-4">
              <BarChart3 className="w-6 h-6 text-arkos-success" />
            </div>
            <h3 className="text-lg font-semibold text-arkos-text-primary mb-2">Bank-Grade Analysis</h3>
            <p className="text-arkos-text-secondary text-sm">
              Institutional-quality risk assessment for renewable energy investments
            </p>
          </GlassPanel>

          <GlassPanel className="p-6 text-center" hover>
            <div className="w-12 h-12 bg-arkos-warning/20 rounded-lg flex items-center justify-center mx-auto mb-4">
              <Globe className="w-6 h-6 text-arkos-warning" />
            </div>
            <h3 className="text-lg font-semibold text-arkos-text-primary mb-2">Real-Time Data</h3>
            <p className="text-arkos-text-secondary text-sm">
              Live grid operator data and transmission infrastructure intelligence
            </p>
          </GlassPanel>
        </div>

        {/* Stats Bar */}
        <div className="mt-16 w-full max-w-4xl">
          <GlassPanel className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 text-center">
              <div>
                <div className="text-2xl font-mono font-bold text-arkos-success">
                  <AnimatedCounter value={47} suffix="B" prefix="$" />
                </div>
                <div className="text-arkos-text-secondary text-sm">Projects Analyzed</div>
              </div>
              <div>
                <div className="text-2xl font-mono font-bold text-arkos-accent">
                  <AnimatedCounter value={99.7} suffix="%" />
                </div>
                <div className="text-arkos-text-secondary text-sm">Accuracy Rate</div>
              </div>
              <div>
                <div className="text-2xl font-mono font-bold text-arkos-warning">
                  <AnimatedCounter value={5} suffix=" min" />
                </div>
                <div className="text-arkos-text-secondary text-sm">Average Analysis</div>
              </div>
              <div>
                <div className="text-2xl font-mono font-bold text-arkos-text-primary">
                  <AnimatedCounter value={24} suffix="/7" />
                </div>
                <div className="text-arkos-text-secondary text-sm">Grid Monitoring</div>
              </div>
            </div>
          </GlassPanel>
        </div>
      </div>
    </div>
  )
}
