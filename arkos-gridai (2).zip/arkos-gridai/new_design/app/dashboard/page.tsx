"use client"

import { useState, useEffect } from "react"
import { GlassPanel } from "@/components/ui/glass-panel"
import { AnimatedCounter } from "@/components/ui/animated-counter"
import { StatusIndicator } from "@/components/ui/status-indicator"
import { Activity, Zap, AlertTriangle, TrendingUp, MapPin, Clock, DollarSign, Shield } from "lucide-react"

export default function Dashboard() {
  const [activeAnalyses, setActiveAnalyses] = useState([
    { id: 1, site: "Solar Farm Alpha", progress: 75, status: "processing" as const },
    { id: 2, site: "Wind Park Beta", progress: 45, status: "processing" as const },
    { id: 3, site: "Battery Storage Gamma", progress: 90, status: "processing" as const },
  ])

  const [portfolioMetrics] = useState({
    totalCapacity: 2847,
    activeProjects: 23,
    riskScore: 7.2,
    avgIRR: 12.4,
  })

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveAnalyses((prev) =>
        prev.map((analysis) => ({
          ...analysis,
          progress: Math.min(100, analysis.progress + Math.random() * 5),
        })),
      )
    }, 2000)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="min-h-screen bg-arkos-primary p-6 ml-64">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-arkos-text-primary mb-2">Command Center</h1>
          <p className="text-arkos-text-secondary">Real-time grid intelligence and portfolio monitoring</p>
        </div>

        {/* Main Grid - 4 Quadrants */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 h-[calc(100vh-200px)]">
          {/* Top Left: Active Analyses */}
          <GlassPanel className="p-6" glow>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-arkos-text-primary flex items-center space-x-2">
                <Activity className="w-5 h-5 text-arkos-accent" />
                <span>Active Analyses</span>
              </h2>
              <StatusIndicator status="processing" label="3 Running" />
            </div>

            <div className="space-y-4">
              {activeAnalyses.map((analysis) => (
                <div
                  key={analysis.id}
                  className="bg-arkos-secondary/50 rounded-lg p-4 border border-arkos-border-subtle"
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-arkos-text-primary font-medium">{analysis.site}</span>
                    <span className="text-arkos-text-secondary text-sm">{Math.round(analysis.progress)}%</span>
                  </div>
                  <div className="w-full bg-arkos-border-subtle rounded-full h-2 mb-2">
                    <div
                      className="bg-gradient-to-r from-arkos-accent to-arkos-success h-2 rounded-full transition-all duration-500"
                      style={{ width: `${analysis.progress}%` }}
                    ></div>
                  </div>
                  <div className="flex items-center justify-between text-xs text-arkos-text-secondary">
                    <span>Grid connection analysis</span>
                    <span className="flex items-center space-x-1">
                      <Clock className="w-3 h-3" />
                      <span>2 min remaining</span>
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </GlassPanel>

          {/* Top Right: Portfolio Health */}
          <GlassPanel className="p-6" glow>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-arkos-text-primary flex items-center space-x-2">
                <TrendingUp className="w-5 h-5 text-arkos-success" />
                <span>Portfolio Health</span>
              </h2>
              <StatusIndicator status="online" label="Healthy" />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-arkos-secondary/50 rounded-lg p-4 border border-arkos-border-subtle">
                <div className="flex items-center space-x-2 mb-2">
                  <Zap className="w-4 h-4 text-arkos-accent" />
                  <span className="text-arkos-text-secondary text-sm">Total Capacity</span>
                </div>
                <div className="text-2xl font-mono font-bold text-arkos-text-primary">
                  <AnimatedCounter value={portfolioMetrics.totalCapacity} suffix=" MW" />
                </div>
              </div>

              <div className="bg-arkos-secondary/50 rounded-lg p-4 border border-arkos-border-subtle">
                <div className="flex items-center space-x-2 mb-2">
                  <MapPin className="w-4 h-4 text-arkos-success" />
                  <span className="text-arkos-text-secondary text-sm">Active Projects</span>
                </div>
                <div className="text-2xl font-mono font-bold text-arkos-text-primary">
                  <AnimatedCounter value={portfolioMetrics.activeProjects} />
                </div>
              </div>

              <div className="bg-arkos-secondary/50 rounded-lg p-4 border border-arkos-border-subtle">
                <div className="flex items-center space-x-2 mb-2">
                  <Shield className="w-4 h-4 text-arkos-warning" />
                  <span className="text-arkos-text-secondary text-sm">Risk Score</span>
                </div>
                <div className="text-2xl font-mono font-bold text-arkos-warning">
                  <AnimatedCounter value={portfolioMetrics.riskScore} suffix="/10" />
                </div>
              </div>

              <div className="bg-arkos-secondary/50 rounded-lg p-4 border border-arkos-border-subtle">
                <div className="flex items-center space-x-2 mb-2">
                  <DollarSign className="w-4 h-4 text-arkos-success" />
                  <span className="text-arkos-text-secondary text-sm">Avg IRR</span>
                </div>
                <div className="text-2xl font-mono font-bold text-arkos-success">
                  <AnimatedCounter value={portfolioMetrics.avgIRR} suffix="%" />
                </div>
              </div>
            </div>
          </GlassPanel>

          {/* Bottom Left: Grid Heatmap */}
          <GlassPanel className="p-6" glow>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-arkos-text-primary flex items-center space-x-2">
                <MapPin className="w-5 h-5 text-arkos-warning" />
                <span>Grid Heatmap</span>
              </h2>
              <div className="text-arkos-text-secondary text-sm">Australia • Live Data</div>
            </div>

            <div className="relative h-64 bg-arkos-secondary/30 rounded-lg border border-arkos-border-subtle overflow-hidden">
              {/* Simplified Australia Map Representation */}
              <div className="absolute inset-0 bg-gradient-to-br from-arkos-accent/20 via-arkos-success/20 to-arkos-warning/20"></div>

              {/* Grid Points */}
              <div className="absolute top-1/4 left-1/3 w-3 h-3 bg-arkos-success rounded-full animate-breathe"></div>
              <div className="absolute top-1/2 left-1/4 w-3 h-3 bg-arkos-warning rounded-full animate-breathe"></div>
              <div className="absolute top-1/3 right-1/3 w-3 h-3 bg-arkos-accent rounded-full animate-breathe"></div>
              <div className="absolute bottom-1/3 left-1/2 w-3 h-3 bg-arkos-danger rounded-full animate-breathe"></div>

              {/* Legend */}
              <div className="absolute bottom-4 left-4 space-y-1">
                <div className="flex items-center space-x-2 text-xs">
                  <div className="w-2 h-2 bg-arkos-success rounded-full"></div>
                  <span className="text-arkos-text-secondary">Low Congestion</span>
                </div>
                <div className="flex items-center space-x-2 text-xs">
                  <div className="w-2 h-2 bg-arkos-warning rounded-full"></div>
                  <span className="text-arkos-text-secondary">Medium Congestion</span>
                </div>
                <div className="flex items-center space-x-2 text-xs">
                  <div className="w-2 h-2 bg-arkos-danger rounded-full"></div>
                  <span className="text-arkos-text-secondary">High Congestion</span>
                </div>
              </div>
            </div>
          </GlassPanel>

          {/* Bottom Right: Recent Alerts */}
          <GlassPanel className="p-6" glow>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-arkos-text-primary flex items-center space-x-2">
                <AlertTriangle className="w-5 h-5 text-arkos-warning" />
                <span>Recent Alerts</span>
              </h2>
              <StatusIndicator status="warning" label="3 Active" />
            </div>

            <div className="space-y-3">
              <div className="bg-arkos-warning/10 border border-arkos-warning/30 rounded-lg p-3">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="text-arkos-text-primary font-medium text-sm">Grid Congestion Alert</div>
                    <div className="text-arkos-text-secondary text-xs mt-1">
                      NSW Region - Transmission constraints detected
                    </div>
                  </div>
                  <div className="text-arkos-text-secondary text-xs">2m ago</div>
                </div>
              </div>

              <div className="bg-arkos-accent/10 border border-arkos-accent/30 rounded-lg p-3">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="text-arkos-text-primary font-medium text-sm">New Regulation Update</div>
                    <div className="text-arkos-text-secondary text-xs mt-1">
                      AEMO market rule changes affecting queue positions
                    </div>
                  </div>
                  <div className="text-arkos-text-secondary text-xs">15m ago</div>
                </div>
              </div>

              <div className="bg-arkos-success/10 border border-arkos-success/30 rounded-lg p-3">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="text-arkos-text-primary font-medium text-sm">Analysis Complete</div>
                    <div className="text-arkos-text-secondary text-xs mt-1">
                      Solar Farm Delta - Bankability score: 8.7/10
                    </div>
                  </div>
                  <div className="text-arkos-text-secondary text-xs">1h ago</div>
                </div>
              </div>
            </div>
          </GlassPanel>
        </div>
      </div>
    </div>
  )
}
