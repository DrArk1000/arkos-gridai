"use client"

import { useState, useEffect } from "react"
import { GlassPanel } from "@/components/ui/glass-panel"
import { AnimatedCounter } from "@/components/ui/animated-counter"
import { StatusIndicator } from "@/components/ui/status-indicator"
import {
  TrendingUp,
  TrendingDown,
  Activity,
  DollarSign,
  Zap,
  AlertTriangle,
  BarChart3,
  LineChart,
  PieChart,
  Globe,
} from "lucide-react"

interface MarketData {
  region: string
  price: number
  change: number
  volume: number
  congestion: "low" | "medium" | "high"
}

interface NewsItem {
  id: string
  title: string
  sentiment: "positive" | "negative" | "neutral"
  time: string
  impact: "high" | "medium" | "low"
}

export default function MarketPage() {
  const [marketData, setMarketData] = useState<MarketData[]>([
    { region: "NSW", price: 45.67, change: 2.3, volume: 8234, congestion: "medium" },
    { region: "VIC", price: 38.92, change: -1.8, volume: 7456, congestion: "low" },
    { region: "QLD", price: 52.14, change: 4.7, volume: 6789, congestion: "high" },
    { region: "SA", price: 41.33, change: 0.9, volume: 4567, congestion: "medium" },
    { region: "WA", price: 35.78, change: -0.5, volume: 3456, congestion: "low" },
  ])

  const [newsItems] = useState<NewsItem[]>([
    {
      id: "1",
      title: "AEMO announces new transmission investment framework",
      sentiment: "positive",
      time: "2m ago",
      impact: "high",
    },
    {
      id: "2",
      title: "Grid congestion increases in Queensland region",
      sentiment: "negative",
      time: "15m ago",
      impact: "medium",
    },
    {
      id: "3",
      title: "Renewable energy certificates trading up 12%",
      sentiment: "positive",
      time: "1h ago",
      impact: "medium",
    },
    {
      id: "4",
      title: "New interconnector project receives approval",
      sentiment: "positive",
      time: "2h ago",
      impact: "high",
    },
  ])

  const [queueData] = useState([
    { position: 1, project: "Solar Farm Alpha", capacity: 150, status: "approved", timeline: "Q2 2024" },
    { position: 2, project: "Wind Park Beta", capacity: 200, status: "review", timeline: "Q3 2024" },
    { position: 3, project: "Battery Storage Gamma", capacity: 100, status: "pending", timeline: "Q4 2024" },
    { position: 4, project: "Hybrid Delta", capacity: 250, status: "pending", timeline: "Q1 2025" },
    { position: 5, project: "Solar Farm Epsilon", capacity: 180, status: "pending", timeline: "Q2 2025" },
  ])

  // Simulate real-time price updates
  useEffect(() => {
    const interval = setInterval(() => {
      setMarketData((prev) =>
        prev.map((region) => ({
          ...region,
          price: region.price + (Math.random() - 0.5) * 2,
          change: region.change + (Math.random() - 0.5) * 0.5,
          volume: region.volume + Math.floor((Math.random() - 0.5) * 100),
        })),
      )
    }, 5000)

    return () => clearInterval(interval)
  }, [])

  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case "positive":
        return "text-arkos-success"
      case "negative":
        return "text-arkos-danger"
      default:
        return "text-arkos-text-secondary"
    }
  }

  const getSentimentIcon = (sentiment: string) => {
    switch (sentiment) {
      case "positive":
        return <TrendingUp className="w-3 h-3" />
      case "negative":
        return <TrendingDown className="w-3 h-3" />
      default:
        return <Activity className="w-3 h-3" />
    }
  }

  const getCongestionColor = (congestion: string) => {
    switch (congestion) {
      case "low":
        return "text-arkos-success bg-arkos-success/10 border-arkos-success/20"
      case "medium":
        return "text-arkos-warning bg-arkos-warning/10 border-arkos-warning/20"
      case "high":
        return "text-arkos-danger bg-arkos-danger/10 border-arkos-danger/20"
      default:
        return "text-arkos-text-secondary"
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "approved":
        return "text-arkos-success bg-arkos-success/10 border-arkos-success/20"
      case "review":
        return "text-arkos-warning bg-arkos-warning/10 border-arkos-warning/20"
      case "pending":
        return "text-arkos-text-secondary bg-arkos-border-subtle/10 border-arkos-border-subtle/20"
      default:
        return "text-arkos-text-secondary"
    }
  }

  return (
    <div className="min-h-screen bg-arkos-primary p-6 ml-64">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-arkos-text-primary mb-2">Market Surveillance</h1>
          <p className="text-arkos-text-secondary">Real-time energy market intelligence and trading floor analytics</p>
        </div>

        {/* Market Overview */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-8">
          <GlassPanel className="p-4" glow>
            <div className="flex items-center space-x-2 mb-2">
              <DollarSign className="w-4 h-4 text-arkos-success" />
              <span className="text-arkos-text-secondary text-sm">Avg Price</span>
            </div>
            <div className="text-xl font-mono font-bold text-arkos-text-primary">
              $<AnimatedCounter value={42.77} />
            </div>
            <div className="text-xs text-arkos-success">+2.1% today</div>
          </GlassPanel>

          <GlassPanel className="p-4" glow>
            <div className="flex items-center space-x-2 mb-2">
              <Activity className="w-4 h-4 text-arkos-accent" />
              <span className="text-arkos-text-secondary text-sm">Volume</span>
            </div>
            <div className="text-xl font-mono font-bold text-arkos-text-primary">
              <AnimatedCounter value={30.5} suffix="k" />
            </div>
            <div className="text-xs text-arkos-accent">MWh traded</div>
          </GlassPanel>

          <GlassPanel className="p-4" glow>
            <div className="flex items-center space-x-2 mb-2">
              <Zap className="w-4 h-4 text-arkos-warning" />
              <span className="text-arkos-text-secondary text-sm">Demand</span>
            </div>
            <div className="text-xl font-mono font-bold text-arkos-text-primary">
              <AnimatedCounter value={28.9} suffix="k" />
            </div>
            <div className="text-xs text-arkos-warning">MW current</div>
          </GlassPanel>

          <GlassPanel className="p-4" glow>
            <div className="flex items-center space-x-2 mb-2">
              <AlertTriangle className="w-4 h-4 text-arkos-danger" />
              <span className="text-arkos-text-secondary text-sm">Constraints</span>
            </div>
            <div className="text-xl font-mono font-bold text-arkos-text-primary">
              <AnimatedCounter value={7} />
            </div>
            <div className="text-xs text-arkos-danger">Active alerts</div>
          </GlassPanel>

          <GlassPanel className="p-4" glow>
            <div className="flex items-center space-x-2 mb-2">
              <Globe className="w-4 h-4 text-arkos-text-primary" />
              <span className="text-arkos-text-secondary text-sm">Renewable</span>
            </div>
            <div className="text-xl font-mono font-bold text-arkos-text-primary">
              <AnimatedCounter value={67} suffix="%" />
            </div>
            <div className="text-xs text-arkos-success">Generation mix</div>
          </GlassPanel>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Regional Price Matrix */}
          <div className="lg:col-span-2">
            <GlassPanel className="p-6 h-96" glow>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold text-arkos-text-primary flex items-center space-x-2">
                  <BarChart3 className="w-5 h-5 text-arkos-accent" />
                  <span>Regional Price Matrix</span>
                </h2>
                <StatusIndicator status="online" label="Live Data" />
              </div>

              <div className="space-y-3">
                {marketData.map((region) => (
                  <div
                    key={region.region}
                    className="bg-arkos-secondary/30 border border-arkos-border-subtle rounded-lg p-4"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <div className="text-arkos-text-primary font-mono font-bold text-lg">{region.region}</div>
                        <div
                          className={`px-2 py-1 rounded-full text-xs border ${getCongestionColor(region.congestion)}`}
                        >
                          {region.congestion} congestion
                        </div>
                      </div>
                      <div className="flex items-center space-x-6">
                        <div className="text-right">
                          <div className="text-arkos-text-primary font-mono font-bold">${region.price.toFixed(2)}</div>
                          <div
                            className={`text-xs flex items-center space-x-1 ${
                              region.change >= 0 ? "text-arkos-success" : "text-arkos-danger"
                            }`}
                          >
                            {region.change >= 0 ? (
                              <TrendingUp className="w-3 h-3" />
                            ) : (
                              <TrendingDown className="w-3 h-3" />
                            )}
                            <span>
                              {region.change >= 0 ? "+" : ""}
                              {region.change.toFixed(1)}%
                            </span>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-arkos-text-secondary text-sm">Volume</div>
                          <div className="text-arkos-text-primary font-mono">{region.volume.toLocaleString()}</div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </GlassPanel>
          </div>

          {/* News Feed */}
          <div className="lg:col-span-1">
            <GlassPanel className="p-6 h-96" glow>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold text-arkos-text-primary flex items-center space-x-2">
                  <Activity className="w-5 h-5 text-arkos-warning" />
                  <span>Market News</span>
                </h2>
                <div className="text-arkos-text-secondary text-sm">Live Feed</div>
              </div>

              <div className="space-y-4 overflow-y-auto">
                {newsItems.map((item) => (
                  <div key={item.id} className="bg-arkos-secondary/30 border border-arkos-border-subtle rounded-lg p-3">
                    <div className="flex items-start justify-between mb-2">
                      <div className={`flex items-center space-x-1 ${getSentimentColor(item.sentiment)}`}>
                        {getSentimentIcon(item.sentiment)}
                        <span className="text-xs font-medium uppercase">{item.impact} Impact</span>
                      </div>
                      <div className="text-arkos-text-secondary text-xs">{item.time}</div>
                    </div>
                    <div className="text-arkos-text-primary text-sm leading-relaxed">{item.title}</div>
                  </div>
                ))}
              </div>
            </GlassPanel>
          </div>
        </div>

        {/* Queue Display & Correlation Matrix */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
          {/* Connection Queue */}
          <GlassPanel className="p-6" glow>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-arkos-text-primary flex items-center space-x-2">
                <LineChart className="w-5 h-5 text-arkos-success" />
                <span>Connection Queue</span>
              </h2>
              <div className="text-arkos-text-secondary text-sm">Order Book Style</div>
            </div>

            <div className="space-y-2">
              <div className="grid grid-cols-5 gap-4 text-xs text-arkos-text-secondary font-medium border-b border-arkos-border-subtle pb-2">
                <span>Position</span>
                <span>Project</span>
                <span>Capacity</span>
                <span>Status</span>
                <span>Timeline</span>
              </div>

              {queueData.map((item) => (
                <div
                  key={item.position}
                  className="grid grid-cols-5 gap-4 text-sm py-2 hover:bg-arkos-secondary/20 rounded transition-colors"
                >
                  <span className="text-arkos-accent font-mono">#{item.position}</span>
                  <span className="text-arkos-text-primary">{item.project}</span>
                  <span className="text-arkos-text-primary font-mono">{item.capacity} MW</span>
                  <span className={`px-2 py-1 rounded-full text-xs border ${getStatusColor(item.status)}`}>
                    {item.status}
                  </span>
                  <span className="text-arkos-text-secondary">{item.timeline}</span>
                </div>
              ))}
            </div>
          </GlassPanel>

          {/* Correlation Matrix */}
          <GlassPanel className="p-6" glow>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-arkos-text-primary flex items-center space-x-2">
                <PieChart className="w-5 h-5 text-arkos-warning" />
                <span>Regional Correlation</span>
              </h2>
              <div className="text-arkos-text-secondary text-sm">Price Relationships</div>
            </div>

            <div className="grid grid-cols-6 gap-2 text-xs">
              <div></div>
              {["NSW", "VIC", "QLD", "SA", "WA"].map((region) => (
                <div key={region} className="text-center text-arkos-text-secondary font-mono">
                  {region}
                </div>
              ))}

              {["NSW", "VIC", "QLD", "SA", "WA"].map((rowRegion, i) => (
                <div key={rowRegion} className="contents">
                  <div className="text-arkos-text-secondary font-mono">{rowRegion}</div>
                  {["NSW", "VIC", "QLD", "SA", "WA"].map((colRegion, j) => {
                    const correlation = i === j ? 1.0 : Math.random() * 0.8 + 0.1
                    const intensity = Math.floor(correlation * 255)
                    return (
                      <div
                        key={colRegion}
                        className="h-8 flex items-center justify-center text-xs font-mono rounded"
                        style={{
                          backgroundColor: `rgba(37, 99, 235, ${correlation * 0.8})`,
                          color: correlation > 0.5 ? "white" : "#94A3B8",
                        }}
                      >
                        {correlation.toFixed(2)}
                      </div>
                    )
                  })}
                </div>
              ))}
            </div>
          </GlassPanel>
        </div>
      </div>
    </div>
  )
}
