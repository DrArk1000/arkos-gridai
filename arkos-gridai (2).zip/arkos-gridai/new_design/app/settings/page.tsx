"use client"

import { useState } from "react"
import { GlassPanel } from "@/components/ui/glass-panel"
import { StatusIndicator } from "@/components/ui/status-indicator"
import { Key, Bell, Palette, Shield, Database, Monitor, Eye, Save, RotateCcw } from "lucide-react"

export default function SettingsPage() {
  const [activeTab, setActiveTab] = useState("api")
  const [apiKeys, setApiKeys] = useState([
    { id: "1", name: "Production API", key: "ak_prod_••••••••••••••••", status: "active", lastUsed: "2 hours ago" },
    { id: "2", name: "Development API", key: "ak_dev_••••••••••••••••", status: "active", lastUsed: "1 day ago" },
    { id: "3", name: "Analytics API", key: "ak_analytics_••••••••••••", status: "inactive", lastUsed: "1 week ago" },
  ])

  const [notifications, setNotifications] = useState({
    email: true,
    push: true,
    sms: false,
    slack: true,
    critical: true,
    warnings: true,
    info: false,
  })

  const [theme, setTheme] = useState("midnight")
  const [soundEnabled, setSoundEnabled] = useState(true)

  const tabs = [
    { id: "api", label: "API Keys", icon: Key },
    { id: "notifications", label: "Notifications", icon: Bell },
    { id: "appearance", label: "Appearance", icon: Palette },
    { id: "security", label: "Security", icon: Shield },
    { id: "data", label: "Data Sources", icon: Database },
    { id: "display", label: "Display", icon: Monitor },
  ]

  const themes = [
    { id: "midnight", name: "Midnight", description: "Deep blue with subtle accents" },
    { id: "deep-space", name: "Deep Space", description: "Darker variant with purple hints" },
    { id: "void", name: "Void", description: "Pure black for OLED displays" },
    { id: "arctic", name: "Arctic", description: "Cool blue-white theme" },
  ]

  return (
    <div className="min-h-screen bg-arkos-primary p-6 ml-64">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-arkos-text-primary mb-2">Settings Laboratory</h1>
          <p className="text-arkos-text-secondary">Advanced configuration and system preferences</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Settings Navigation */}
          <div className="lg:col-span-1">
            <GlassPanel className="p-6" glow>
              <h2 className="text-lg font-semibold text-arkos-text-primary mb-4">Configuration</h2>
              <div className="space-y-2">
                {tabs.map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg transition-all duration-200 text-left ${
                      activeTab === tab.id
                        ? "bg-arkos-accent/20 text-arkos-accent border border-arkos-accent/30"
                        : "text-arkos-text-secondary hover:text-arkos-text-primary hover:bg-arkos-secondary/30"
                    }`}
                  >
                    <tab.icon className="w-4 h-4" />
                    <span className="text-sm">{tab.label}</span>
                  </button>
                ))}
              </div>
            </GlassPanel>
          </div>

          {/* Settings Content */}
          <div className="lg:col-span-3">
            <GlassPanel className="p-6" glow>
              {activeTab === "api" && (
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xl font-semibold text-arkos-text-primary">API Key Management</h3>
                    <button className="bg-gradient-to-r from-arkos-accent to-arkos-success px-4 py-2 rounded-lg text-white font-medium text-sm hover:shadow-lg transition-all duration-200">
                      Generate New Key
                    </button>
                  </div>

                  <div className="space-y-4">
                    {apiKeys.map((apiKey) => (
                      <div
                        key={apiKey.id}
                        className="bg-arkos-secondary/30 border border-arkos-border-subtle rounded-lg p-4"
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-4">
                            <div>
                              <div className="text-arkos-text-primary font-medium">{apiKey.name}</div>
                              <div className="text-arkos-text-secondary text-sm font-mono">{apiKey.key}</div>
                            </div>
                            <StatusIndicator
                              status={apiKey.status === "active" ? "online" : "error"}
                              label={apiKey.status}
                            />
                          </div>
                          <div className="flex items-center space-x-2">
                            <div className="text-right text-sm">
                              <div className="text-arkos-text-secondary">Last used</div>
                              <div className="text-arkos-text-primary">{apiKey.lastUsed}</div>
                            </div>
                            <button className="p-2 text-arkos-text-secondary hover:text-arkos-danger transition-colors">
                              <Eye className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="bg-arkos-warning/10 border border-arkos-warning/20 rounded-lg p-4">
                    <div className="flex items-start space-x-3">
                      <Shield className="w-5 h-5 text-arkos-warning mt-0.5" />
                      <div>
                        <div className="text-arkos-text-primary font-medium text-sm mb-1">
                          Security Zone Classification
                        </div>
                        <div className="text-arkos-text-secondary text-sm">
                          API keys are classified by security zones. Production keys have elevated privileges and should
                          be rotated regularly.
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === "notifications" && (
                <div className="space-y-6">
                  <h3 className="text-xl font-semibold text-arkos-text-primary">Notification Control Matrix</h3>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h4 className="text-lg font-medium text-arkos-text-primary mb-4">Delivery Channels</h4>
                      <div className="space-y-4">
                        {Object.entries({
                          email: "Email Notifications",
                          push: "Push Notifications",
                          sms: "SMS Alerts",
                          slack: "Slack Integration",
                        }).map(([key, label]) => (
                          <div key={key} className="flex items-center justify-between">
                            <span className="text-arkos-text-primary">{label}</span>
                            <button
                              onClick={() =>
                                setNotifications((prev) => ({ ...prev, [key]: !prev[key as keyof typeof prev] }))
                              }
                              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                                notifications[key as keyof typeof notifications]
                                  ? "bg-arkos-accent"
                                  : "bg-arkos-border-subtle"
                              }`}
                            >
                              <span
                                className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                                  notifications[key as keyof typeof notifications] ? "translate-x-6" : "translate-x-1"
                                }`}
                              />
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div>
                      <h4 className="text-lg font-medium text-arkos-text-primary mb-4">Alert Types</h4>
                      <div className="space-y-4">
                        {Object.entries({
                          critical: "Critical Alerts",
                          warnings: "Warning Messages",
                          info: "Information Updates",
                        }).map(([key, label]) => (
                          <div key={key} className="flex items-center justify-between">
                            <span className="text-arkos-text-primary">{label}</span>
                            <button
                              onClick={() =>
                                setNotifications((prev) => ({ ...prev, [key]: !prev[key as keyof typeof prev] }))
                              }
                              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                                notifications[key as keyof typeof notifications]
                                  ? "bg-arkos-accent"
                                  : "bg-arkos-border-subtle"
                              }`}
                            >
                              <span
                                className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                                  notifications[key as keyof typeof notifications] ? "translate-x-6" : "translate-x-1"
                                }`}
                              />
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === "appearance" && (
                <div className="space-y-6">
                  <h3 className="text-xl font-semibold text-arkos-text-primary">Theme Customization</h3>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {themes.map((themeOption) => (
                      <div
                        key={themeOption.id}
                        onClick={() => setTheme(themeOption.id)}
                        className={`p-4 rounded-lg border cursor-pointer transition-all duration-200 ${
                          theme === themeOption.id
                            ? "border-arkos-accent bg-arkos-accent/10"
                            : "border-arkos-border-subtle hover:border-arkos-accent/50"
                        }`}
                      >
                        <div className="flex items-center space-x-3 mb-2">
                          <div
                            className={`w-4 h-4 rounded-full ${
                              themeOption.id === "midnight"
                                ? "bg-arkos-accent"
                                : themeOption.id === "deep-space"
                                  ? "bg-purple-500"
                                  : themeOption.id === "void"
                                    ? "bg-gray-900"
                                    : "bg-cyan-400"
                            }`}
                          ></div>
                          <span className="text-arkos-text-primary font-medium">{themeOption.name}</span>
                        </div>
                        <p className="text-arkos-text-secondary text-sm">{themeOption.description}</p>
                      </div>
                    ))}
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-arkos-text-primary font-medium">Sound Effects</div>
                        <div className="text-arkos-text-secondary text-sm">
                          Enable audio feedback for critical alerts
                        </div>
                      </div>
                      <button
                        onClick={() => setSoundEnabled(!soundEnabled)}
                        className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                          soundEnabled ? "bg-arkos-accent" : "bg-arkos-border-subtle"
                        }`}
                      >
                        <span
                          className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                            soundEnabled ? "translate-x-6" : "translate-x-1"
                          }`}
                        />
                      </button>
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-arkos-text-primary font-medium">High Performance Mode</div>
                        <div className="text-arkos-text-secondary text-sm">
                          Enable WebGL backgrounds and advanced animations
                        </div>
                      </div>
                      <button className="relative inline-flex h-6 w-11 items-center rounded-full bg-arkos-accent">
                        <span className="inline-block h-4 w-4 transform rounded-full bg-white translate-x-6" />
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* Save/Reset Actions */}
              <div className="flex items-center justify-end space-x-4 pt-6 border-t border-arkos-border-subtle">
                <button className="flex items-center space-x-2 px-4 py-2 border border-arkos-border-prominent text-arkos-text-primary rounded-lg hover:border-arkos-accent/50 transition-all duration-200">
                  <RotateCcw className="w-4 h-4" />
                  <span>Reset</span>
                </button>
                <button className="flex items-center space-x-2 bg-gradient-to-r from-arkos-accent to-arkos-success px-6 py-2 rounded-lg text-white font-medium hover:shadow-lg transition-all duration-200">
                  <Save className="w-4 h-4" />
                  <span>Save Changes</span>
                </button>
              </div>
            </GlassPanel>
          </div>
        </div>
      </div>
    </div>
  )
}
