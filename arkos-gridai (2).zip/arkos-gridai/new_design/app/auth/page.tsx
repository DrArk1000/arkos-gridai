"use client"

import { useState } from "react"
import { GlassPanel } from "@/components/ui/glass-panel"
import { Eye, EyeOff, Fingerprint, Shield } from "lucide-react"

export default function AuthPage() {
  const [showPassword, setShowPassword] = useState(false)
  const [isScanning, setIsScanning] = useState(false)
  const [authStep, setAuthStep] = useState<'login' | 'mfa' | 'biometric'>('login')

  const handleBiometricScan = () => {
    setIsScanning(true)
    setTimeout(() => {
      setIsScanning(false)
      setAuthStep('mfa')
    }, 3000)
  }

  return (
    <div className="min-h-screen bg-arkos-primary relative overflow-hidden flex items-center justify-center">
      {/* Animated Background */}
      <div className="absolute inset-0 bg-grid-pattern bg-grid opacity-20"></div>
      <div className="absolute inset-0 bg-gradient-to-br from-arkos-accent/10 via-transparent to-arkos-success/10"></div>
      
      {/* Scanning Lines */}
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-arkos-accent to-transparent animate-grid-scan opacity-60"></div>
      <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-arkos-success to-transparent animate-grid-scan opacity-60" style={{ animationDelay: '2s' }}></div>

      <div className="relative z-10 w-full max-w-md px-4">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center space-x-3 mb-4">
            <div className="w-12 h-12 bg-gradient-to-br from-arkos-accent to-arkos-success rounded-xl flex items-center justify-center animate-float">
              <div className="w-6 h-6 border-2 border-white rounded-lg transform rotate-45"></div>
            </div>
            <div>
              <div className="text-2xl font-bold text-arkos-text-primary">Arkos</div>
              <div className="text-arkos-text-secondary text-sm">Grid Intelligence</div>
            </div>
          </div>
          <div className="text-arkos-text-secondary text-sm">Secure Access Portal</div>
        </div>

        {authStep === 'login' && (
          <GlassPanel className="p-8" glow>
            <div className="space-y-6">
              <div className="text-center mb-6">
                <h1 className="text-xl font-semibold text-arkos-text-primary mb-2">Authentication Required</h1>
                <p className="text-arkos-text-secondary text-sm">Access critical grid infrastructure systems</p>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm text-arkos-text-secondary mb-2">Email Address</label>
                  <input
                    type="email"
                    className="w-full px-4 py-3 bg-arkos-secondary/50 border border-arkos-border-subtle rounded-lg text-arkos-text-primary focus:border-arkos-accent focus:outline-none transition-all duration-200"
                    placeholder="operator@arkos.energy"
                  />
                </div>

                <div>
                  <label className="block text-sm text-arkos-text-secondary mb-2">Password</label>
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      className="w-full px-4 py-3 bg-arkos-secondary/50 border border-arkos-border-subtle rounded-lg text-arkos-text-primary focus:border-arkos-accent focus:outline-none transition-all duration-200 pr-12"
                      placeholder="••••••••••••"
                    />
                    <button
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-arkos-text-secondary hover:text-arkos-text-primary transition-colors"
                    >
                      {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                    </button>
                  </div>
                </div>

                <button
                  onClick={() => setAuthStep('biometric')}
                  className="w-full bg-gradient-to-r from-arkos-accent to-arkos-success px-6 py-3 rounded-lg text-white font-medium hover:shadow-lg hover:shadow-arkos-accent/30 transition-all duration-300"
                >
                  Proceed to Biometric Scan
                </button>

                <div className="text-center">
                  <button className="text-arkos-text-secondary text-sm hover:text-arkos-accent transition-colors">
                    Forgot your credentials?
                  </button>
                </div>
              </div>
            </div>
          </GlassPanel>
        )}

        {authStep === 'biometric' && (
          <GlassPanel className="p-8" glow>
            <div className="text-center space-y-6">
              <div>
                <h2 className="text-xl font-semibold text-arkos-text-primary mb-2">Biometric Authentication</h2>
                <p className="text-arkos-text-secondary text-sm">Place your finger on the scanner</p>
              </div>

              {/* Biometric Scanner Animation */}
              <div className="relative mx-auto w-32 h-32">
                <div className={`w-32 h-32 rounded-full border-4 border-arkos-accent/30 flex items-center justify-center ${isScanning ? 'animate-pulse' : ''}`}>
                  <div className={`w-24 h-24 rounded-full border-2 flex items-center justify-center transition-all duration-300 ${
                    isScanning ? 'border-arkos-success bg-arkos-success/10' : 'border-arkos-accent/50'
                  }`}>
                    <Fingerprint className={`w-12 h-12 transition-all duration-300 ${
                      isScanning ? 'text-arkos-success' : 'text-arkos-accent'
                    }`} />
                  </div>
                </div>
                
                {/* Scanning Animation */}
                {isScanning && (
                  <div className="absolute inset-0 rounded-full border-4 border-arkos-success animate-ping"></div>
                )}
              </div>

              <div className="space-y-4">
                <button
                  onClick={handleBiometricScan}
                  disabled={isScanning}
                  className="w-full bg-gradient-to-r from-arkos-accent to-arkos-success px-6 py-3 rounded-lg text-white font-medium disabled:opacity-50 disabled:cursor-not-allowed hover:shadow-lg hover:shadow-arkos-accent/30 transition-all duration-300"
                >
                  {isScanning ? 'Scanning...' : 'Start Biometric Scan'}
                </button>

                <button
                  onClick={() => setAuthStep('login')}
                  className="w-full px-6 py-3 border border-arkos-border-prominent text-arkos-text-primary rounded-lg hover:border-arkos-accent/50 transition-all duration-200"
                >
                  Use Alternative Method
                </button>
              </div>
            </div>
          </GlassPanel>
        )}

        {authStep === 'mfa' && (
          <GlassPanel className="p-8" glow>
            <div className="space-y-6">
              <div className="text-center">
                <div className="w-16 h-16 bg-arkos-success/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Shield className="w-8 h-8 text-arkos-success" />
                </div>
                <h2 className="text-xl font-semibold text-arkos-text-primary mb-2">Multi-Factor Authentication</h2>
                <p className="text-arkos-text-secondary text-sm">Enter the 6-digit code from your authenticator app</p>
              </div>

              <div className="flex space-x-2 justify-center">
                {[...Array(6)].map((_, i) => (
                  <input
                    key={i}
                    type="text"
                    maxLength={1}
                    className="w-12 h-12 text-center bg-arkos-secondary/50 border border-arkos-border-subtle rounded-lg text-arkos-text-primary font-mono text-lg focus:border-arkos-accent focus:outline-none transition-all duration-200"
                  />
                ))}
              </div>

              <div className="space-y-4">
                <button className="w-full bg-gradient-to-r from-arkos-accent to-arkos-success px-6 py-3 rounded-lg text-white font-medium hover:shadow-lg hover:shadow-arkos-accent/30 transition-all duration-300">
                  Verify & Enter System
                </button>

                <div className="text-center space-y-2">
                  <button className="text-arkos-text-secondary text-sm hover:text-arkos-accent transition-colors">
                    Resend Code
                  </button>
                  <div className="text-xs text-arkos-text-muted">
                    Code expires in <span className="text-arkos-warning font-mono">2:34</span>
                  </div>
                </div>
              </div>
            </div>
          </GlassPanel>
        )}

        {/* Security Clearance Levels */}
        <div className="mt-8">
          <GlassPanel className="p-4">
            <div className="text-center">
              <div className="text-xs text-arkos-text-secondary mb-2">Security Clearance Levels</div>
              <div className="flex justify-center space-x-4 text-xs">
                <div className="flex items-center space-x-1">
                  <div className="w-2 h-2 bg-arkos-success rounded-full"></div>
                  <span className="text-arkos-text-secondary">Operator</span>
                </div>
                <div className="flex items-center space-x-1">
                  <div className="w-2 h-2 bg-arkos-warning rounded-full"></div>
                  <span className="text-arkos-text-secondary">Analyst</span>
                </div>
                <div className="flex items-center space-x-1">
                  <div className="w-2 h-2 bg-arkos-danger rounded-full"></div>
                  <span className="text-arkos-text-secondary">Administrator</span>
                </div>
              </div>
            </div>
          </GlassPanel>
        </div>

        {/* Footer */}
        <div className="text-center mt-8 text-xs text-arkos-\
