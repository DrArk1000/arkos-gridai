"use client"

import { useState, useRef } from "react"
import { GlassPanel } from "@/components/ui/glass-panel"
import { StatusIndicator } from "@/components/ui/status-indicator"
import { MapPin, Zap, Settings, Play, Pause, RotateCcw, Download, Layers } from "lucide-react"

export default function AnalyzePage() {
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [analysisProgress, setAnalysisProgress] = useState(0)
  const [selectedCoords, setSelectedCoords] = useState({ lat: "", lon: "" })
  const [analysisSteps] = useState([
    "Initializing grid data connection...",
    "Analyzing transmission infrastructure...",
    "Calculating congestion patterns...",
    "Assessing interconnection queue...",
    "Evaluating regulatory compliance...",
    "Computing financial projections...",
    "Generating risk assessment...",
    "Finalizing bankability score...",
  ])
  const [currentStep, setCurrentStep] = useState(0)

  const mapRef = useRef<HTMLDivElement>(null)

  const startAnalysis = () => {
    if (!selectedCoords.lat || !selectedCoords.lon) return

    setIsAnalyzing(true)
    setAnalysisProgress(0)
    setCurrentStep(0)

    const interval = setInterval(() => {
      setAnalysisProgress((prev) => {
        const newProgress = prev + Math.random() * 15 + 5
        if (newProgress >= 100) {
          clearInterval(interval)
          setIsAnalyzing(false)
          setCurrentStep(analysisSteps.length - 1)
          return 100
        }
        setCurrentStep(Math.floor((newProgress / 100) * analysisSteps.length))
        return newProgress
      })
    }, 800)
  }

  return (
    <div className="min-h-screen bg-arkos-primary p-6 ml-64">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-arkos-text-primary mb-2">Site Analysis</h1>
          <p className="text-arkos-text-secondary">AI-powered grid connection analysis in under 5 minutes</p>
        </div>

        {/* Three Panel Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[calc(100vh-200px)]">
          {/* Left Panel: Map */}
          <div className="lg:col-span-1">
            <GlassPanel className="h-full p-6" glow>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-arkos-text-primary flex items-center space-x-2">
                  <MapPin className="w-5 h-5 text-arkos-accent" />
                  <span>Site Selection</span>
                </h2>
                <div className="flex items-center space-x-2">
                  <Layers className="w-4 h-4 text-arkos-text-secondary" />
                  <span className="text-xs text-arkos-text-secondary">Transmission Layer</span>
                </div>
              </div>

              {/* Map Container */}
              <div
                ref={mapRef}
                className="h-64 bg-arkos-secondary/30 rounded-lg border border-arkos-border-subtle mb-4 relative overflow-hidden cursor-crosshair"
                onClick={(e) => {
                  const rect = e.currentTarget.getBoundingClientRect()
                  const x = ((e.clientX - rect.left) / rect.width) * 360 - 180
                  const y = 90 - ((e.clientY - rect.top) / rect.height) * 180
                  setSelectedCoords({
                    lat: y.toFixed(6),
                    lon: x.toFixed(6),
                  })
                }}
              >
                {/* Hexagonal Grid Overlay */}
                <div className="absolute inset-0 opacity-20">
                  <svg width="100%" height="100%" className="text-arkos-accent">
                    <defs>
                      <pattern id="hexagons" x="0" y="0" width="40" height="35" patternUnits="userSpaceOnUse">
                        <polygon
                          points="20,2 32,10 32,25 20,33 8,25 8,10"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="0.5"
                        />
                      </pattern>
                    </defs>
                    <rect width="100%" height="100%" fill="url(#hexagons)" />
                  </svg>
                </div>

                {/* Selected Point */}
                {selectedCoords.lat && selectedCoords.lon && (
                  <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                    <div className="w-4 h-4 bg-arkos-accent rounded-full animate-pulse shadow-lg shadow-arkos-accent/50"></div>
                  </div>
                )}

                {/* Transmission Lines */}
                <svg className="absolute inset-0 w-full h-full">
                  <line x1="10%" y1="20%" x2="90%" y2="80%" stroke="#2563EB" strokeWidth="2" opacity="0.6" />
                  <line x1="20%" y1="10%" x2="80%" y2="90%" stroke="#2563EB" strokeWidth="2" opacity="0.6" />
                  <line x1="30%" y1="70%" x2="70%" y2="30%" stroke="#10B981" strokeWidth="3" opacity="0.8" />
                </svg>
              </div>

              {/* Coordinates Input */}
              <div className="space-y-3">
                <div>
                  <label className="block text-xs text-arkos-text-secondary mb-1">Latitude</label>
                  <input
                    type="text"
                    value={selectedCoords.lat}
                    onChange={(e) => setSelectedCoords((prev) => ({ ...prev, lat: e.target.value }))}
                    className="w-full px-3 py-2 bg-arkos-secondary/50 border border-arkos-border-subtle rounded text-arkos-text-primary text-sm focus:border-arkos-accent focus:outline-none"
                    placeholder="Click map or enter coordinates"
                  />
                </div>
                <div>
                  <label className="block text-xs text-arkos-text-secondary mb-1">Longitude</label>
                  <input
                    type="text"
                    value={selectedCoords.lon}
                    onChange={(e) => setSelectedCoords((prev) => ({ ...prev, lon: e.target.value }))}
                    className="w-full px-3 py-2 bg-arkos-secondary/50 border border-arkos-border-subtle rounded text-arkos-text-primary text-sm focus:border-arkos-accent focus:outline-none"
                    placeholder="Click map or enter coordinates"
                  />
                </div>
              </div>
            </GlassPanel>
          </div>

          {/* Center Panel: Analysis Feed */}
          <div className="lg:col-span-1">
            <GlassPanel className="h-full p-6" glow>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-arkos-text-primary flex items-center space-x-2">
                  <Zap className="w-5 h-5 text-arkos-success" />
                  <span>Analysis Feed</span>
                </h2>
                <StatusIndicator
                  status={isAnalyzing ? "processing" : "online"}
                  label={isAnalyzing ? "Processing" : "Ready"}
                />
              </div>

              {/* Progress Bar */}
              {isAnalyzing && (
                <div className="mb-6">
                  <div className="flex justify-between text-xs text-arkos-text-secondary mb-2">
                    <span>Analysis Progress</span>
                    <span>{Math.round(analysisProgress)}%</span>
                  </div>
                  <div className="w-full bg-arkos-border-subtle rounded-full h-2">
                    <div
                      className="bg-gradient-to-r from-arkos-accent to-arkos-success h-2 rounded-full transition-all duration-300"
                      style={{ width: `${analysisProgress}%` }}
                    ></div>
                  </div>
                </div>
              )}

              {/* Analysis Steps */}
              <div className="space-y-3 flex-1 overflow-y-auto">
                {analysisSteps.map((step, index) => (
                  <div
                    key={index}
                    className={`p-3 rounded-lg border transition-all duration-300 ${
                      index <= currentStep
                        ? "bg-arkos-success/10 border-arkos-success/30 text-arkos-text-primary"
                        : "bg-arkos-secondary/30 border-arkos-border-subtle text-arkos-text-secondary"
                    }`}
                  >
                    <div className="flex items-center space-x-2">
                      <div
                        className={`w-2 h-2 rounded-full ${
                          index < currentStep
                            ? "bg-arkos-success"
                            : index === currentStep && isAnalyzing
                              ? "bg-arkos-accent animate-pulse"
                              : "bg-arkos-border-subtle"
                        }`}
                      ></div>
                      <span className="text-sm">{step}</span>
                    </div>
                  </div>
                ))}
              </div>

              {/* Control Buttons */}
              <div className="flex space-x-2 mt-6">
                <button
                  onClick={startAnalysis}
                  disabled={!selectedCoords.lat || !selectedCoords.lon || isAnalyzing}
                  className="flex-1 bg-gradient-to-r from-arkos-accent to-arkos-success px-4 py-2 rounded text-white font-medium disabled:opacity-50 disabled:cursor-not-allowed hover:shadow-lg transition-all duration-200 flex items-center justify-center space-x-2"
                >
                  {isAnalyzing ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  <span>{isAnalyzing ? "Analyzing..." : "Start Analysis"}</span>
                </button>
                <button className="px-4 py-2 border border-arkos-border-prominent text-arkos-text-primary rounded hover:border-arkos-accent/50 transition-all duration-200">
                  <RotateCcw className="w-4 h-4" />
                </button>
              </div>
            </GlassPanel>
          </div>

          {/* Right Panel: Parameters */}
          <div className="lg:col-span-1">
            <GlassPanel className="h-full p-6" glow>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-arkos-text-primary flex items-center space-x-2">
                  <Settings className="w-5 h-5 text-arkos-warning" />
                  <span>Project Parameters</span>
                </h2>
              </div>

              <div className="space-y-6">
                {/* Project Type */}
                <div>
                  <label className="block text-sm text-arkos-text-secondary mb-2">Project Type</label>
                  <select className="w-full px-3 py-2 bg-arkos-secondary/50 border border-arkos-border-subtle rounded text-arkos-text-primary focus:border-arkos-accent focus:outline-none">
                    <option>Solar PV</option>
                    <option>Wind Farm</option>
                    <option>Battery Storage</option>
                    <option>Hybrid</option>
                  </select>
                </div>

                {/* Capacity Slider */}
                <div>
                  <label className="block text-sm text-arkos-text-secondary mb-2">
                    Capacity: <span className="text-arkos-accent font-mono">100 MW</span>
                  </label>
                  <input
                    type="range"
                    min="1"
                    max="500"
                    defaultValue="100"
                    className="w-full h-2 bg-arkos-border-subtle rounded-lg appearance-none cursor-pointer slider"
                  />
                </div>

                {/* Connection Voltage */}
                <div>
                  <label className="block text-sm text-arkos-text-secondary mb-2">Connection Voltage</label>
                  <select className="w-full px-3 py-2 bg-arkos-secondary/50 border border-arkos-border-subtle rounded text-arkos-text-primary focus:border-arkos-accent focus:outline-none">
                    <option>132 kV</option>
                    <option>275 kV</option>
                    <option>330 kV</option>
                    <option>500 kV</option>
                  </select>
                </div>

                {/* Timeline */}
                <div>
                  <label className="block text-sm text-arkos-text-secondary mb-2">
                    Target COD: <span className="text-arkos-success font-mono">Q2 2026</span>
                  </label>
                  <input
                    type="range"
                    min="2024"
                    max="2030"
                    defaultValue="2026"
                    className="w-full h-2 bg-arkos-border-subtle rounded-lg appearance-none cursor-pointer slider"
                  />
                </div>

                {/* Risk Tolerance */}
                <div>
                  <label className="block text-sm text-arkos-text-secondary mb-2">
                    Risk Tolerance: <span className="text-arkos-warning font-mono">Medium</span>
                  </label>
                  <input
                    type="range"
                    min="1"
                    max="5"
                    defaultValue="3"
                    className="w-full h-2 bg-arkos-border-subtle rounded-lg appearance-none cursor-pointer slider"
                  />
                  <div className="flex justify-between text-xs text-arkos-text-secondary mt-1">
                    <span>Conservative</span>
                    <span>Aggressive</span>
                  </div>
                </div>
              </div>
            </GlassPanel>
          </div>
        </div>

        {/* Bottom Ticker */}
        <div className="mt-6">
          <GlassPanel className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-6 text-sm">
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-arkos-success rounded-full animate-breathe"></div>
                  <span className="text-arkos-text-secondary">Queue Position:</span>
                  <span className="text-arkos-text-primary font-mono">#47 of 234</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-arkos-warning rounded-full animate-breathe"></div>
                  <span className="text-arkos-text-secondary">Est. Timeline:</span>
                  <span className="text-arkos-text-primary font-mono">18 months</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-arkos-accent rounded-full animate-breathe"></div>
                  <span className="text-arkos-text-secondary">Grid Congestion:</span>
                  <span className="text-arkos-text-primary font-mono">Medium</span>
                </div>
              </div>
              <button className="flex items-center space-x-2 px-4 py-2 border border-arkos-border-prominent text-arkos-text-primary rounded hover:border-arkos-accent/50 transition-all duration-200">
                <Download className="w-4 h-4" />
                <span>Export Data</span>
              </button>
            </div>
          </GlassPanel>
        </div>
      </div>
    </div>
  )
}
