import type { Config } from "tailwindcss"
import defaultConfig from "shadcn/ui/tailwind.config"

const config: Config = {
  ...defaultConfig,
  content: [
    ...defaultConfig.content,
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    ...defaultConfig.theme,
    extend: {
      ...defaultConfig.theme.extend,
      colors: {
        ...defaultConfig.theme.extend.colors,
        // Arkos Design System
        arkos: {
          primary: "#0A0E27", // Deep dark blue background
          secondary: "#0D1117", // Slightly lighter background
          accent: "#2563EB", // Electric blue
          success: "#10B981", // Success green
          warning: "#F59E0B", // Warning amber
          danger: "#EF4444", // Danger red
          text: {
            primary: "#E2E8F0", // Primary text
            secondary: "#94A3B8", // Secondary text
            muted: "#64748B", // Muted text
          },
          border: {
            subtle: "#1E293B", // Subtle borders
            prominent: "#334155", // Prominent borders
            glow: "#2563EB40", // Glowing borders
          },
          glass: {
            bg: "#0A0E2780", // Glass background
            border: "#2563EB20", // Glass border
          },
        },
      },
      fontFamily: {
        mono: ["JetBrains Mono", "Monaco", "Consolas", "monospace"],
        sans: ["Inter", "system-ui", "sans-serif"],
      },
      animation: {
        "pulse-glow": "pulse-glow 2s ease-in-out infinite",
        float: "float 3s ease-in-out infinite",
        "grid-scan": "grid-scan 4s linear infinite",
        counter: "counter 0.3s ease-out",
        breathe: "breathe 2s ease-in-out infinite",
      },
      keyframes: {
        "pulse-glow": {
          "0%, 100%": {
            boxShadow: "0 0 5px rgba(37, 99, 235, 0.5)",
            borderColor: "rgba(37, 99, 235, 0.5)",
          },
          "50%": {
            boxShadow: "0 0 20px rgba(37, 99, 235, 0.8)",
            borderColor: "rgba(37, 99, 235, 0.8)",
          },
        },
        float: {
          "0%, 100%": { transform: "translateY(0px)" },
          "50%": { transform: "translateY(-10px)" },
        },
        "grid-scan": {
          "0%": { transform: "translateX(-100%)" },
          "100%": { transform: "translateX(100vw)" },
        },
        counter: {
          "0%": { transform: "scale(1.2)", opacity: "0.7" },
          "100%": { transform: "scale(1)", opacity: "1" },
        },
        breathe: {
          "0%, 100%": { opacity: "0.6" },
          "50%": { opacity: "1" },
        },
      },
      backdropBlur: {
        xs: "2px",
      },
      backgroundImage: {
        "grid-pattern": `
          linear-gradient(rgba(37, 99, 235, 0.1) 1px, transparent 1px),
          linear-gradient(90deg, rgba(37, 99, 235, 0.1) 1px, transparent 1px)
        `,
        holographic: `
          linear-gradient(45deg, 
            rgba(37, 99, 235, 0.1) 0%, 
            rgba(16, 185, 129, 0.1) 50%, 
            rgba(245, 158, 11, 0.1) 100%)
        `,
      },
      backgroundSize: {
        grid: "20px 20px",
      },
    },
  },
  plugins: [...defaultConfig.plugins, require("tailwindcss-animate")],
}

export default config
