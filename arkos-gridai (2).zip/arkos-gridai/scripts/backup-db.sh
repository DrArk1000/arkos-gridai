#!/bin/bash

# Exit on error
set -e

# Configuration
BACKUP_DIR="./backups"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BACKUP_FILE="${BACKUP_DIR}/arkos_db_${TIMESTAMP}.dump"
KEEP_DAYS=30

# Create backup directory if it doesn't exist
mkdir -p "$BACKUP_DIR"

echo "Starting database backup..."

# Load environment variables
if [ -f .env ]; then
    export $(grep -v '^#' .env | xargs)
fi

# Set default values if not provided in .env
PG_USER=${POSTGRES_USER:-postgres}
PG_PASSWORD=${POSTGRES_PASSWORD:-postgres}
PG_DB=${POSTGRES_DB:-arkos_gridai}
PG_HOST=${POSTGRES_HOST:-localhost}
PG_PORT=${POSTGRES_PORT:-5432}

# Create backup
PGPASSWORD="$PG_PASSWORD" pg_dump -h "$PG_HOST" -p "$PG_PORT" -U "$PG_USER" -F c -b -v -f "$BACKUP_FILE" "$PG_DB"

# Check if backup was successful
if [ $? -eq 0 ]; then
    echo "Database backup created successfully: $BACKUP_FILE"
    
    # Set permissions
    chmod 600 "$BACKUP_FILE"
    
    # Clean up old backups
    echo "Cleaning up backups older than $KEEP_DAYS days..."
    find "$BACKUP_DIR" -name "arkos_db_*.dump" -type f -mtime +$KEEP_DAYS -delete -print
    
    echo "Backup process completed successfully"
    exit 0
else
    echo "Error: Database backup failed"
    # Remove the failed backup file if it was created
    [ -f "$BACKUP_FILE" ] && rm -f "$BACKUP_FILE"
    exit 1
fi
