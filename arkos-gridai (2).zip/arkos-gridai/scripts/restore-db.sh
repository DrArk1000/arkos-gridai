#!/bin/bash

# Exit on error
set -e

# Check if backup file is provided
if [ -z "$1" ]; then
    echo "Usage: $0 <backup_file.dump>"
    echo "Available backups:"
    ls -l ./backups/*.dump 2>/dev/null || echo "No backup files found in ./backups/"
    exit 1
fi

BACKUP_FILE=$1

# Check if backup file exists
if [ ! -f "$BACKUP_FILE" ]; then
    echo "Error: Backup file not found: $BACKUP_FILE"
    exit 1
fi

# Load environment variables
if [ -f .env ]; then
    export $(grep -v '^#' .env | xargs)
fi

# Set default values if not provided in .env
PG_USER=${POSTGRES_USER:-postgres}
PG_PASSWORD=${POSTGRES_PASSWORD:-postgres}
PG_DB=${POSTGRES_DB:-arkos_gridai}
PG_HOST=${POSTGRES_HOST:-localhost}
PG_PORT=${POSTGRES_PORT:-5432}

# Ask for confirmation
read -p "WARNING: This will DROP the existing database '$PG_DB' and restore from '$BACKUP_FILE'. Are you sure? [y/N] " -n 1 -r
echo

if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "Restore cancelled."
    exit 1
fi

echo "Starting database restore from $BACKUP_FILE..."

# Drop and recreate the database
PGPASSWORD="$PG_PASSWORD" dropdb -h "$PG_HOST" -p "$PG_PORT" -U "$PG_USER" --if-exists "$PG_DB"
PGPASSWORD="$PG_PASSWORD" createdb -h "$PG_HOST" -p "$PG_PORT" -U "$PG_USER" "$PG_DB"

# Restore the database
PGPASSWORD="$PG_PASSWORD" pg_restore -h "$PG_HOST" -p "$PG_PORT" -U "$PG_USER" -d "$PG_DB" -v "$BACKUP_FILE"

if [ $? -eq 0 ]; then
    echo "Database restore completed successfully!"
    
    # Run database migrations if needed
    echo "Running database migrations..."
    docker-compose -f docker-compose.prod.yml exec backend alembic upgrade head
    
    echo "Database is now ready to use."
else
    echo "Error: Database restore failed"
    exit 1
fi
