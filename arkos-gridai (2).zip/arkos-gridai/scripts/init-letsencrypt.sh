#!/bin/bash

# Exit on error
set -e

# Check if domain is provided
if [ -z "$1" ] || [ -z "$2" ]; then
    echo "Usage: $0 <domain> <email>"
    exit 1
fi

DOMAIN=$1
EMAIL=$2

# Create necessary directories
mkdir -p certs/conf/live/$DOMAIN

# Create a dummy certificate for initial nginx startup
echo "Creating dummy certificate for $DOMAIN..."
openssl req -x509 -nodes -newkey rsa:4096 \
    -days 1 \
    -keyout certs/conf/live/$DOMAIN/privkey.pem \
    -out certs/conf/live/$DOMAIN/fullchain.pem \
    -subj "/CN=localhost"

# Start Nginx with dummy certificate
echo "Starting Nginx with dummy certificate..."
docker-compose -f docker-compose.prod.yml up -d nginx

# Delete dummy certificate
echo "Deleting dummy certificate..."
rm -rf certs/conf/live/$DOMAIN/*

# Get Let's Encrypt certificate
echo "Requesting Let's Encrypt certificate for $DOMAIN..."
docker run -it --rm \
    -v "$(pwd)/certs/conf:/etc/letsencrypt" \
    -v "$(pwd)/certs/www:/var/www/certbot" \
    certbot/certbot \
    certonly \
    --webroot \
    --webroot-path=/var/www/certbot \
    --email $EMAIL \
    --agree-tos \
    --no-eff-email \
    -d $DOMAIN \
    --force-renewal

# Update Nginx configuration with the new certificate
echo "Updating Nginx configuration..."
sed -i "s/yourdomain.com/$DOMAIN/g" nginx/conf.d/default.conf

# Restart Nginx to apply changes
echo "Restarting Nginx with new certificate..."
docker-compose -f docker-compose.prod.yml restart nginx

echo "\nSSL certificate setup complete!"
echo "Your site is now available at: https://$DOMAIN"
