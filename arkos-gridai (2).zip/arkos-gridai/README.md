# Arkos GridAI

A comprehensive AI-powered solar development platform that provides detailed site analysis, risk assessment, and financial modeling for renewable energy projects.

## 🚀 Features

- **User Authentication & Authorization**
  - Secure JWT-based authentication
  - Role-based access control
  - User profile management

- **Site Analysis**
  - Geospatial analysis with interactive maps
  - Risk assessment and scoring
  - Connection feasibility analysis
  - Curtailment prediction

- **Financial Modeling**
  - Cost estimation
  - Revenue projection
  - Payback period calculation
  - ROI analysis

- **Reporting**
  - Customizable PDF reports
  - Data export (CSV, Excel)
  - Shareable analysis links

## 🏗️ Project Structure

```
arkos-gridai/
├── backend/                 # FastAPI backend
│   ├── app/
│   │   ├── api/            # API routes
│   │   ├── core/           # Core functionality
│   │   ├── models/         # Database models
│   │   ├── schemas/        # Pydantic models
│   │   ├── services/       # Business logic
│   │   └── worker.py       # Celery tasks
│   ├── tests/              # Backend tests
│   ├── requirements.txt    # Python dependencies
│   └── Dockerfile         # Backend Dockerfile
│
├── frontend/               # Next.js frontend
│   ├── public/             # Static files
│   ├── src/
│   │   ├── components/     # Reusable components
│   │   ├── pages/          # Next.js pages
│   │   ├── styles/         # Global styles
│   │   └── utils/          # Utility functions
│   ├── package.json
│   └── next.config.js
│
├── infra/                  # Infrastructure as Code
│   ├── terraform/         # Terraform configurations
│   └── kubernetes/        # Kubernetes manifests
│
├── docker-compose.yml      # Development environment
└── README.md              # This file
```

## 🛠️ Development Setup

### Prerequisites

- Docker and Docker Compose
- Python 3.10+
- Node.js 18+ and npm/yarn
- PostgreSQL 14+
- Redis 7+

### Quick Start with Docker Compose

1. Clone the repository:
   ```bash
   git clone https://github.com/yourusername/arkos-gridai.git
   cd arkos-gridai
   ```

2. Copy the example environment file:
   ```bash
   cp .env.example .env
   ```

3. Update the `.env` file with your configuration.

4. Start the services:
   ```bash
   docker-compose up -d
   ```

5. Initialize the database:
   ```bash
   docker-compose exec backend python -m scripts.init_db
   ```

6. Access the application:
   - Frontend: http://localhost:3000
   - Backend API: http://localhost:8000
   - API Docs: http://localhost:8000/docs
   - Flower (Celery Monitor): http://localhost:5555

### Manual Setup (Development)

#### Backend

1. Create and activate a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: .\venv\Scripts\activate
   ```

2. Install dependencies:
   ```bash
   cd backend
   pip install -r requirements.txt
   ```

3. Set up environment variables in `.env` (copy from `.env.example`)

4. Run database migrations:
   ```bash
   alembic upgrade head
   ```

5. Start the development server:
   ```bash
   uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
   ```

#### Frontend

1. Install dependencies:
   ```bash
   cd frontend
   npm install
   ```

2. Create a `.env.local` file with:
   ```
   NEXT_PUBLIC_API_URL=http://localhost:8000/api/v1
   NEXT_PUBLIC_MAPBOX_TOKEN=your_mapbox_token_here
   ```

3. Start the development server:
   ```bash
   npm run dev
   ```

## 🧪 Testing

### Backend Tests

```bash
cd backend
pytest
```

### Frontend Tests

```bash
cd frontend
npm test
```

## 🚀 Deployment

### Production with Docker

1. Build the production images:
   ```bash
   docker-compose -f docker-compose.prod.yml build
   ```

2. Start the services:
   ```bash
   docker-compose -f docker-compose.prod.yml up -d
   ```

### Kubernetes

See the `infra/kubernetes` directory for deployment manifests.

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🤝 Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## Key Features

- Australia-first grid bankability analysis
- Real-time queue intelligence
- TRI (Transmission, Risk, Interconnection) scoring
- PDF report generation
- Waitlist management

## License

Proprietary - All rights reserved
